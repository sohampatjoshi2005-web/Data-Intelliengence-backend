from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any, Dict, List

from app.core.config import settings
from app.core.llm_clients import LLMRouter
from app.services.bedrock_embeddings import bedrock_embed_texts
from app.unstructured.schemas import KBState
from app.unstructured.storage import AlloyLikeKBStore
from app.unstructured.workflow import build_kb_workflow, run_kb_sequential_fallback


class KnowledgeBaseService:
    def __init__(self) -> None:
        self.workflow = build_kb_workflow()
        self.store = AlloyLikeKBStore()
        self.router = LLMRouter()

    def build_from_bytes(
        self,
        filename: str,
        payload: bytes,
        dataset_id: str,
        llm_provider: str = "bedrock",
        fast_mode: bool | None = None,
        chunk_cap: int | None = None,
        skip_ner: bool | None = None,
        skip_pii: bool | None = None,
        skip_enrichment: bool | None = None,
        enrichment_batch_size: int | None = None,
        enrichment_workers: int | None = None,
        embedding_batch_size: int | None = None,
        embedding_workers: int | None = None,
    ) -> Dict[str, Any]:
        with tempfile.NamedTemporaryFile(delete=False, suffix=Path(filename).suffix) as tmp:
            tmp.write(payload)
            tmp_path = tmp.name

        state: KBState = {
            "dataset_id": dataset_id or filename,
            "file_path": tmp_path,
            "llm_provider": llm_provider,
            "warnings": [],
            "fast_mode": settings.kb_fast_mode if fast_mode is None else bool(fast_mode),
            "chunk_cap": settings.kb_chunk_cap if chunk_cap is None else int(chunk_cap),
            "chunk_size_tokens": settings.kb_chunk_size_tokens,
            "chunk_overlap_tokens": settings.kb_chunk_overlap_tokens,
            "skip_ner": settings.kb_skip_ner if skip_ner is None else bool(skip_ner),
            "skip_pii": settings.kb_skip_pii if skip_pii is None else bool(skip_pii),
            "skip_enrichment": settings.kb_skip_enrichment if skip_enrichment is None else bool(skip_enrichment),
            "enrichment_batch_size": settings.kb_enrich_batch_size if enrichment_batch_size is None else int(enrichment_batch_size),
            "enrichment_workers": settings.kb_enrich_workers if enrichment_workers is None else int(enrichment_workers),
            "embedding_batch_size": settings.kb_embed_batch_size if embedding_batch_size is None else int(embedding_batch_size),
            "embedding_workers": settings.kb_embed_workers if embedding_workers is None else int(embedding_workers),
        }
        try:
            final = self.workflow.invoke(state) if self.workflow else run_kb_sequential_fallback(state)
        finally:
            try:
                Path(tmp_path).unlink(missing_ok=True)
            except Exception:
                pass

        self.store.init_schema()
        feature_json = (final.get("persistence") or {}).get("document_features", {})
        self.store.persist_document(
            dataset_id=final["dataset_id"],
            source_name=filename,
            language=final.get("language", "unknown"),
            feature_json=feature_json,
        )
        stored = self.store.persist_chunks(final["dataset_id"], final.get("chunks", []))
        return {
            "dataset_id": final["dataset_id"],
            "language": final.get("language", "unknown"),
            "chunk_count": len(final.get("chunks", [])),
            "stored_chunks": stored,
            "headings_count": len(final.get("headings", [])),
            "entities_count": len(final.get("entities", [])),
            "warnings": final.get("warnings", []),
            "performance": {
                "fast_mode": bool(state["fast_mode"]),
                "chunk_cap": int(state["chunk_cap"]),
                "skip_ner": bool(state["skip_ner"]),
                "skip_pii": bool(state["skip_pii"]),
                "skip_enrichment": bool(state["skip_enrichment"]),
                "enrichment_batch_size": int(state["enrichment_batch_size"]),
                "enrichment_workers": int(state["enrichment_workers"]),
                "embedding_batch_size": int(state["embedding_batch_size"]),
                "embedding_workers": int(state["embedding_workers"]),
            },
        }

    def _embed_query(self, query: str) -> List[float]:
        try:
            return bedrock_embed_texts([query])[0]
        except Exception:
            return []

    def query(self, dataset_id: str, query: str, top_k: int = 8, llm_provider: str = "bedrock") -> Dict[str, Any]:
        q_vec = self._embed_query(query)
        bm25_hits = self.store.bm25_search(dataset_id=dataset_id, query=query, limit=max(top_k * 2, 10))
        vec_hits = self.store.vector_search(dataset_id=dataset_id, query_vec=q_vec, limit=max(top_k * 2, 10)) if q_vec else []

        merged: Dict[str, Dict[str, Any]] = {}
        for rank, h in enumerate(bm25_hits):
            cid = str(h.get("chunk_id"))
            item = merged.setdefault(cid, {"chunk_id": cid, "summary": h.get("summary", ""), "snippet": str(h.get("chunk_text", ""))[:420], "bm25": 0.0, "vector": 0.0})
            item["bm25"] = max(float(item.get("bm25", 0.0)), float(h.get("bm25_score", 0.0)))
            item["bm25_rank"] = min(int(item.get("bm25_rank", 10_000)), rank + 1)
        for rank, h in enumerate(vec_hits):
            cid = str(h.get("chunk_id"))
            item = merged.setdefault(cid, {"chunk_id": cid, "summary": h.get("summary", ""), "snippet": str(h.get("chunk_text", ""))[:420], "bm25": 0.0, "vector": 0.0})
            item["vector"] = max(float(item.get("vector", 0.0)), float(h.get("vector_score", 0.0)))
            item["vector_rank"] = min(int(item.get("vector_rank", 10_000)), rank + 1)

        hits = list(merged.values())
        for h in hits:
            rr_bm25 = 1.0 / (60 + int(h.get("bm25_rank", 9999)))
            rr_vec = 1.0 / (60 + int(h.get("vector_rank", 9999)))
            h["fused_score"] = rr_bm25 + rr_vec
        hits.sort(key=lambda x: x.get("fused_score", 0.0), reverse=True)
        hits = hits[:top_k]

        context = "\n\n".join([f"[{h['chunk_id']}] {h.get('summary','')}\n{h.get('snippet','')}" for h in hits[:5]])
        answer_prompt = (
            "You are a senior knowledge analyst. Using only the context, provide:\n"
            "1) concise answer\n2) professional summary\n3) sentence relationships (bullet list)\n"
            f"Question: {query}\n\nContext:\n{context}"
        )
        answer = self.router.complete(answer_prompt, provider=llm_provider)
        return {
            "dataset_id": dataset_id,
            "query": query,
            "hits": hits,
            "answer": answer,
        }
