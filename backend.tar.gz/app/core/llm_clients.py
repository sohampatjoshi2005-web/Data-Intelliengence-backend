from __future__ import annotations

from openai import OpenAI
import boto3
import json

from .config import settings
from app.services.observability import trace_generation


class LLMRouter:
    """Routes calls through local Ollama or AWS Bedrock."""

    def __init__(self) -> None:
        self._ollama = OpenAI(api_key=settings.ollama_api_key, base_url=settings.ollama_base_url)
        self._bedrock = boto3.client("bedrock-runtime", region_name=settings.bedrock_region)

    def available_providers(self) -> list[str]:
        providers = ["ollama_local"]
        if settings.bedrock_model_id:
            providers.append("bedrock")
        return providers

    def complete(self, prompt: str, provider: str = "ollama_local") -> str:
        try:
            if provider == "bedrock" and settings.bedrock_model_id:
                body = {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": settings.bedrock_max_tokens,
                    "temperature": settings.bedrock_temperature,
                    "messages": [
                        {"role": "user", "content": [{"type": "text", "text": prompt}]}
                    ],
                }
                resp = self._bedrock.invoke_model(
                    modelId=settings.bedrock_model_id,
                    body=json.dumps(body).encode("utf-8"),
                    contentType="application/json",
                    accept="application/json",
                )
                raw = resp["body"].read().decode("utf-8")
                data = json.loads(raw)
                out = ""
                if isinstance(data, dict):
                    content = data.get("content", [])
                    if content and isinstance(content, list):
                        out = content[0].get("text", "") or ""
                trace_generation("llm_bedrock", settings.bedrock_model_id, prompt, out)
                return out or ""

            response = self._ollama.chat.completions.create(
                model=settings.ollama_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
            )
            out = response.choices[0].message.content or ""
            trace_generation("llm_ollama", settings.ollama_model, prompt, out)
            return out
        except Exception as exc:
            return (
                "LLM provider unavailable. Falling back to rules-based behavior. "
                f"Reason: {type(exc).__name__}: {exc}"
            )
