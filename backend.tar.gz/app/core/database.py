import certifi
from motor.motor_asyncio import AsyncIOMotorClient
from app.core.config import settings

class Database:
    client: AsyncIOMotorClient = None

db = Database()

async def get_database():
    if db.client is None:
        db.client = AsyncIOMotorClient(
            settings.mongodb_uri,
            tlsCAFile=certifi.where()
        )
    return db.client.get_database("agentic_ai")

async def get_collection(name: str):
    database = await get_database()
    return database.get_collection(name)
