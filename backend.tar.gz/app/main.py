from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any, Dict

import pandas as pd
import duckdb
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from app.core.config import settings
from app.core.llm_clients import LLMRouter
from app.graph.state import AgentState
from app.graph.workflow import (
    build_workflow,
    build_analytics_workflow,
    run_analytics_insights,
    run_analytics_sequential_fallback,
    run_sequential_fallback,
)
from app.schemas import (
    AnalyticsVisualsResponse,
    AnalyticsInsightsRequest,
    AnalyticsInsightsResponse,
    AnalyticsQueryRequest,
    AnalyticsQueryResponse,
    AnalyticsSQLRequest,
    AnalyticsSQLResponse,
    AnalyticsNLToSQLRequest,
    AnalyticsNLToSQLResponse,
    AnalyticsSQLExplainRequest,
    AnalyticsSQLExplainResponse,
    ChatRequest,
    ChatResponse,
    ConnectorLoadRequest,
    ConnectorLoadResponse,
    ConnectorOrchestrateRequest,
    ConnectorTestRequest,
    ConnectorTestResponse,
    DeepEvalRequest,
    StructuredPreviewResponse,
    StructuredTuneRequest,
    StructuredTuneResponse,
    StructuredPredictTrainRequest,
    StructuredPredictTrainResponse,
    StructuredPredictRequest,
    StructuredPredictResponse,
    StructuredOnlineStartRequest,
    StructuredOnlineStartResponse,
    StructuredOnlineBatchRequest,
    StructuredOnlineBatchResponse,
    StructuredOnlineStatusResponse,
    StructuredOnlineStopResponse,
    TransformationRequest,
    TransformationResponse,
    EdgeQuakeQueryRequest,
    EdgeQuakeQueryResponse,
    EdgeQuakeUploadResponse,
    StructuredExplainRequest,
    StructuredExplainResponse,
    StructuredBusinessSummaryRequest,
    StructuredBusinessSummaryResponse,
    AnalyticsDashboardRequest,
    AnalyticsDashboardResponse,
    StructuredExplainabilityRequest,
    StructuredExplainabilityResponse,
    FeatureStoreMaterializeRequest,
    FeatureStoreReadRequest,
    FeatureStoreUpsertRequest,
    KBBuildResponse,
    KGBuildRequest,
    KGBuildResponse,
    KGQueryRequest,
    KGQueryResponse,
    KGSubgraphRequest,
    KGSubgraphResponse,
    KBQueryRequest,
    KBQueryResponse,
    OrchestrateResponse,
    RegistryApproveRequest,
    RegistryPromoteRequest,
    RegistryRollbackRequest,
    UnstructuredAnalyzeResponse,
)
import requests
import uuid

# --- Soft Imports for ML/heavy services ---
try:
    from app.graph.workflow import (
        build_workflow, build_analytics_workflow, run_analytics_insights,
        run_analytics_sequential_fallback, run_sequential_fallback
    )
except Exception:
    build_workflow = build_analytics_workflow = run_analytics_insights = \
    run_analytics_sequential_fallback = run_sequential_fallback = None

try:
    from app.services.connector_runtime import load_dataframe_from_connector, test_connector
    from app.services.connectors import list_connectors
except Exception:
    load_dataframe_from_connector = test_connector = list_connectors = None

try:
    from app.services.analytics_visuals import generate_visual_pack
except Exception:
    generate_visual_pack = None

try:
    from app.services.analytics_helpers import serialize_result
    from app.services.analytics_llm import AnalyticsModelConfig, chat_complete
except Exception:
    serialize_result = chat_complete = AnalyticsModelConfig = None

try:
    from app.services.deepeval_runner import run_deepeval
except Exception:
    run_deepeval = None

try:
    from app.services.structured_runtime import (
        run_optuna_tuning, train_predictor, predict_with_model,
        start_stream, process_stream_batch, get_stream_status,
        stop_stream, run_explainability
    )
except Exception:
    run_optuna_tuning = train_predictor = predict_with_model = \
    start_stream = process_stream_batch = get_stream_status = \
    stop_stream = run_explainability = None

try:
    from app.services.analytics_dashboard import build_dashboard_stats
except Exception:
    build_dashboard_stats = None

try:
    from app.unstructured.service import KnowledgeBaseService
    from app.unstructured.age_graph import AGEGraphService
except Exception:
    KnowledgeBaseService = AGEGraphService = None

try:
    from app.services.dspy_runtime import dspy_nl_to_sql, dspy_ready
except Exception:
    dspy_nl_to_sql = dspy_ready = None

try:
    from app.agents.analytics_code_generation import _extract_sql
except Exception:
    _extract_sql = None

try:
    from app.services.feature_store import LocalFeatureStore
    from app.services.model_registry import LocalModelRegistry
except Exception:
    LocalFeatureStore = LocalModelRegistry = None

try:
    from app.services.distributed_orchestrator import get_orchestration_status
except Exception:
    get_orchestration_status = None

from app.services.email_service import EmailService

# --- Core Imports (Must exist) ---
from app.core.database import get_collection
from app.models.user import UserCreate, UserLogin, UserInDB, Token
from app.services.auth_service import create_access_token, verify_password, get_password_hash
from app.services.authz import get_current_user_role, require_role
from app.services.data_loader import load_dataframe_from_upload
from app.services.evaluation_center import list_eval_tools
from app.services.preprocessing import apply_preprocessing
from app.services.unstructured_analyze import analyze_unstructured
from app.services.transformations import run_transformation

app = FastAPI(title=settings.app_name)

_DEFAULT_ORIGINS = [
    "http://localhost:5173",
    "http://localhost:3000",
    "http://localhost:8080",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:3000",
    "https://superhumanlythoughts.com",
    "https://www.superhumanlythoughts.com",
    "https://api.superhumanlythoughts.com",
]

origins = (
    _DEFAULT_ORIGINS
    if settings.cors_origins.strip() == "*"
    else [o.strip() for o in settings.cors_origins.split(",")]
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

workflow = build_workflow()
analytics_workflow = build_analytics_workflow()
llm_router = LLMRouter()
kb_service = KnowledgeBaseService()
kg_service = AGEGraphService()
registry = LocalModelRegistry()


def _structured_provider(requested: str) -> str:
    if settings.structured_llm_provider and requested in ("", "ollama_local"):
        return settings.structured_llm_provider
    return requested
feature_store = LocalFeatureStore()




def _run_structured_pipeline(
    df: pd.DataFrame,
    dataset_name: str,
    business_problem: str = "",
    target_column: str = "",
    model_family: str = "",
    fixed_model: str = "",
    llm_provider: str = "ollama_local",
    preprocess_config: Dict[str, Any] | None = None,
) -> OrchestrateResponse:
    df = apply_preprocessing(df, target_column=target_column or None, config=preprocess_config)

    state: AgentState = {
        "business_problem": business_problem,
        "user_prompt": business_problem,
        "dataset_name": dataset_name,
        "dataframe": df,
        "target_column": target_column or None,
        "model_family": model_family or None,
        "fixed_model": fixed_model or None,
        "llm_provider": llm_provider,
        "warnings": [],
    }

    final_state = workflow.invoke(state) if workflow else run_sequential_fallback(state)
    training = dict(final_state.get("training", {}))
    training.pop("model_object", None)
    training.pop("primary_model_object", None)

    return OrchestrateResponse(
        data_profile=final_state.get("data_profile", {}),
        problem_type=final_state.get("problem_type", "classification"),
        pipeline=final_state.get("pipeline", {}),
        training=training,
        evaluation=final_state.get("evaluation", {}),
        deployment=final_state.get("deployment", {}),
        warnings=final_state.get("warnings", []),
    )


def _json_line(event: str, **payload: Any) -> str:
    body = {"event": event, **payload}
    return json.dumps(body, default=str) + "\n"


def _is_distribution_means_query(query: str) -> bool:
    q = query.lower()
    return (
        ("class distribution" in q or "distribution" in q)
        and "mean" in q
        and ("variety" in q or "class" in q or "species" in q)
    )


def _distribution_means_query_payload(df: pd.DataFrame, query: str) -> Dict[str, Any]:
    df_work = df.copy()
    num_cols = df_work.select_dtypes(include=["number"]).columns.tolist()
    cat_cols = [c for c in df_work.columns if c not in num_cols]

    target_col = None
    for c in df_work.columns:
        if str(c).lower() in {"target", "label", "class", "species", "variety"}:
            target_col = c
            break
    if target_col is None and cat_cols:
        target_col = cat_cols[0]
    if target_col is None:
        target_col = df_work.columns[-1]

    df_work = df_work.dropna(subset=[target_col])
    class_counts = df_work[target_col].value_counts(dropna=False)
    class_distribution = [
        {"class": str(idx), "count": int(val), "pct": round(float(val) / max(len(df_work), 1) * 100.0, 2)}
        for idx, val in class_counts.items()
    ]

    preferred = [c for c in ["petal.length", "petal.width", "petal_length", "petal_width"] if c in df_work.columns]
    mean_cols = preferred if preferred else num_cols[:2]
    mean_by_group: list[dict[str, Any]] = []
    if mean_cols:
        means = df_work.groupby(target_col)[mean_cols].mean().reset_index()
        for _, row in means.iterrows():
            rec: dict[str, Any] = {"group": str(row[target_col])}
            for c in mean_cols:
                rec[f"{c}_mean"] = float(row[c])
            mean_by_group.append(rec)

    result_obj = {
        "target_column": str(target_col),
        "row_count": int(len(df_work)),
        "class_distribution": class_distribution,
        "mean_by_group": mean_by_group,
    }
    class_text = ", ".join([f"{d['class']}={d['count']} ({d['pct']}%)" for d in class_distribution]) or "N/A"
    means_text = []
    for row in mean_by_group:
        group_name = str(row.get("group"))
        metric_text = ", ".join([f"{k}={v:.4f}" for k, v in row.items() if k != "group" and isinstance(v, (int, float))])
        if metric_text:
            means_text.append(f"{group_name}: {metric_text}")

    reasoning = (
        f"Computed class distribution and group means for query '{query}'. "
        f"Distribution: {class_text}. "
        f"Group means: {' | '.join(means_text) if means_text else 'N/A'}."
    )
    sql = (
        f"SELECT {target_col}, COUNT(*) AS count, ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct "
        f"FROM iris GROUP BY {target_col};\n"
        f"SELECT {target_col}, "
        + ", ".join([f"AVG({c}) AS {c.replace('.', '_')}_mean" for c in mean_cols])
        + f" FROM iris GROUP BY {target_col};"
    )
    return {
        "should_plot": False,
        "code": sql,
        "code_language": "sql",
        "execution": {"ok": True, "error": None, "result": serialize_result(result_obj), "plot_base64": None},
        "reasoning": reasoning,
    }


def _is_pair_separation_query(query: str) -> bool:
    q = query.lower()
    markers = [
        "best separates",
        "separates each pair",
        "pair of",
        "effect size",
        "threshold",
    ]
    return sum(1 for m in markers if m in q) >= 2


def _is_simple_distribution_query(query: str) -> bool:
    q = query.lower()
    return "distribution" in q and ("first numeric" in q or "numeric column" in q or "histogram" in q)


def _simple_distribution_query_payload(df: pd.DataFrame, query: str) -> Dict[str, Any]:
    df_work = df.copy()
    num_cols = df_work.select_dtypes(include=["number"]).columns.tolist()
    if not num_cols:
        result_obj = {
            "summary": "No numeric columns are available in this dataset, so a numeric distribution cannot be computed.",
            "numeric_column": None,
            "row_count": int(len(df_work)),
        }
        return {
            "should_plot": False,
            "code": "-- No numeric column found for distribution analysis.",
            "code_language": "sql",
            "execution": {"ok": True, "error": None, "result": serialize_result(result_obj), "plot_base64": None},
            "reasoning": "Computed dataset checks and found no numeric columns for distribution analysis.",
        }

    col = num_cols[0]
    s = pd.to_numeric(df_work[col], errors="coerce").dropna()
    if len(s) == 0:
        result_obj = {
            "summary": f"Column `{col}` exists but contains no valid numeric values after cleaning.",
            "numeric_column": col,
            "row_count": int(len(df_work)),
        }
        return {
            "should_plot": False,
            "code": f"-- Column {col} has no usable numeric values after coercion.",
            "code_language": "sql",
            "execution": {"ok": True, "error": None, "result": serialize_result(result_obj), "plot_base64": None},
            "reasoning": f"Distribution check completed for `{col}` but no numeric values were available.",
        }

    key_stats = {
        "count": int(len(s)),
        "mean": float(s.mean()),
        "median": float(s.median()),
        "std": float(s.std(ddof=1)) if len(s) > 1 else 0.0,
        "min": float(s.min()),
        "q1": float(s.quantile(0.25)),
        "q3": float(s.quantile(0.75)),
        "max": float(s.max()),
    }
    result_obj = {
        "numeric_column": col,
        "row_count": int(len(df_work)),
        "key_stats": key_stats,
        "summary": (
            f"The first numeric column is `{col}`. Its distribution centers around "
            f"{key_stats['mean']:.3f} (median {key_stats['median']:.3f}) with spread "
            f"std {key_stats['std']:.3f}, and range {key_stats['min']:.3f} to {key_stats['max']:.3f}."
        ),
    }
    reasoning = (
        f"Computed descriptive distribution metrics for `{col}` including central tendency, spread, and quartiles."
    )
    code = (
        f"SELECT COUNT({col}) AS count, AVG({col}) AS mean, MIN({col}) AS min, MAX({col}) AS max "
        f"FROM iris;"
    )
    return {
        "should_plot": False,
        "code": code,
        "code_language": "sql",
        "execution": {"ok": True, "error": None, "result": serialize_result(result_obj), "plot_base64": None},
        "reasoning": reasoning,
    }


def _pair_separation_query_payload(df: pd.DataFrame, query: str) -> Dict[str, Any]:
    df_work = df.copy()
    num_cols = df_work.select_dtypes(include=["number"]).columns.tolist()
    cat_cols = [c for c in df_work.columns if c not in num_cols]

    target_col = None
    for c in df_work.columns:
        if str(c).lower() in {"target", "label", "class", "species", "variety"}:
            target_col = c
            break
    if target_col is None and cat_cols:
        target_col = cat_cols[0]
    if target_col is None:
        target_col = df_work.columns[-1]

    df_work = df_work.dropna(subset=[target_col])
    classes = [str(v) for v in sorted(df_work[target_col].astype(str).unique().tolist())]
    class_counts = {c: int((df_work[target_col].astype(str) == c).sum()) for c in classes}

    pairwise_best_features: list[dict[str, Any]] = []
    if len(classes) >= 2 and num_cols:
        for i in range(len(classes)):
            for j in range(i + 1, len(classes)):
                c1, c2 = classes[i], classes[j]
                s1 = df_work[df_work[target_col].astype(str) == c1]
                s2 = df_work[df_work[target_col].astype(str) == c2]
                best = None
                best_score = -1.0
                for feature in num_cols:
                    a = pd.to_numeric(s1[feature], errors="coerce").dropna()
                    b = pd.to_numeric(s2[feature], errors="coerce").dropna()
                    if len(a) < 2 or len(b) < 2:
                        continue
                    mean_a, mean_b = float(a.mean()), float(b.mean())
                    std_a, std_b = float(a.std(ddof=1)), float(b.std(ddof=1))
                    pooled = ((std_a**2 + std_b**2) / 2.0) ** 0.5
                    effect_size = abs(mean_a - mean_b) / pooled if pooled > 0 else 0.0
                    threshold = (mean_a + mean_b) / 2.0
                    direction = f"{c1}>{c2}" if mean_a > mean_b else f"{c2}>{c1}"
                    if effect_size > best_score:
                        best_score = effect_size
                        best = {
                            "pair": f"{c1} vs {c2}",
                            "feature": feature,
                            "effect_size": float(effect_size),
                            "threshold_candidate": float(threshold),
                            "direction": direction,
                        }
                if best:
                    pairwise_best_features.append(best)

    if pairwise_best_features:
        easiest = max(pairwise_best_features, key=lambda x: float(x.get("effect_size", 0.0)))
        summary = (
            f"Easiest pair to separate is {easiest['pair']} using {easiest['feature']} "
            f"(effect size {easiest['effect_size']:.3f}, threshold {easiest['threshold_candidate']:.3f})."
        )
    else:
        summary = "Could not compute pairwise separation due to insufficient numeric signal."

    result_obj = {
        "target_column": str(target_col),
        "row_count": int(len(df_work)),
        "class_counts": class_counts,
        "pairwise_best_features": pairwise_best_features,
        "summary": summary,
    }
    reasoning = (
        f"Computed pairwise feature separation for query '{query}' using standardized effect size "
        "(absolute mean difference divided by pooled standard deviation) and midpoint thresholds."
    )
    code = (
        f"-- Pairwise separation blueprint on {target_col}\n"
        f"-- 1) Aggregate means/std per class for each numeric feature.\n"
        f"-- 2) For each class pair and feature: effect_size = abs(mean1-mean2)/sqrt((std1^2+std2^2)/2).\n"
        f"-- 3) Threshold candidate = (mean1+mean2)/2.\n"
        f"-- 4) Pick feature with max effect_size per class pair."
    )
    return {
        "should_plot": False,
        "code": code,
        "code_language": "sql",
        "execution": {"ok": True, "error": None, "result": serialize_result(result_obj), "plot_base64": None},
        "reasoning": reasoning,
    }


def _require_viewer(role: str = Depends(get_current_user_role)) -> None:
    require_role("business/analyst", role)

def _require_data_scientist(role: str = Depends(get_current_user_role)) -> None:
    require_role("data scientist", role)

def _require_ml_engineer(role: str = Depends(get_current_user_role)) -> None:
    require_role("data scientist", role)

def _require_risk_reviewer(role: str = Depends(get_current_user_role)) -> None:
    require_role("admin", role)

def _require_approver(role: str = Depends(get_current_user_role)) -> None:
    require_role("admin", role)

@app.post("/auth/register", response_model=Token)
async def register(user: UserCreate, background_tasks: BackgroundTasks):
    users_col = await get_collection("users")
    existing_user = await users_col.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Custom logic: First user is admin and approved
    user_count = await users_col.count_documents({})
    is_first_user = user_count == 0
    
    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash(user.password)
    
    actual_role = "admin" if is_first_user else user.role
    actual_approved = True if is_first_user else False
    
    new_user = {
        "_id": user_id,
        "email": user.email,
        "role": actual_role,
        "is_approved": actual_approved,
        "hashed_password": hashed_password,
        "created_at": datetime.utcnow()
    }
    
    await users_col.insert_one(new_user)
    
    if not actual_approved:
        background_tasks.add_task(EmailService.notify_registration_received, user.email)
        return Token(access_token="", token_type="bearer", role=actual_role)
        
    access_token = create_access_token(data={"sub": user.email, "role": actual_role})
    return {"access_token": access_token, "token_type": "bearer", "role": actual_role}

@app.post("/auth/login", response_model=Token)
async def login(user_login: UserLogin):
    users_col = await get_collection("users")
    user = await users_col.find_one({"email": user_login.email})
    if not user or not verify_password(user_login.password, user["hashed_password"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    
    if not user.get("is_approved", False):
        raise HTTPException(status_code=403, detail="Awaiting administrative approval")
    
    access_token = create_access_token(data={"sub": user["email"], "role": user["role"]})
    return {"access_token": access_token, "token_type": "bearer", "role": user["role"]}

# Admin Management Routes
@app.get("/admin/users")
async def admin_list_users(_: None = Depends(_require_risk_reviewer)): # Reuse admin-level check
    users_col = await get_collection("users")
    users = await users_col.find().to_list(1000)
    for u in users:
        u["id"] = u.pop("_id")
        u.pop("hashed_password", None)
    return users

@app.post("/admin/users/{user_id}/approve")
async def admin_approve_user(user_id: str, background_tasks: BackgroundTasks, _: None = Depends(_require_risk_reviewer)):
    users_col = await get_collection("users")
    user = await users_col.find_one({"_id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    new_status = not user.get("is_approved", False)
    await users_col.update_one({"_id": user_id}, {"$set": {"is_approved": new_status}})
    
    if new_status:
        background_tasks.add_task(EmailService.notify_access_approved, user["email"], user["role"])
    else:
        background_tasks.add_task(EmailService.notify_access_denied, user["email"])
        
    return {"ok": True, "is_approved": new_status}

@app.patch("/admin/users/{user_id}/role")
async def admin_update_role(user_id: str, payload: dict, _: None = Depends(_require_risk_reviewer)):
    new_role = payload.get("role")
    if new_role not in ["admin", "business/analyst", "data scientist"]:
        raise HTTPException(status_code=400, detail="Invalid role")
    
    users_col = await get_collection("users")
    res = await users_col.update_one({"_id": user_id}, {"$set": {"role": new_role}})
    if res.modified_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"ok": True, "role": new_role}

@app.delete("/admin/users/{user_id}")
async def admin_delete_user(user_id: str, _: None = Depends(_require_risk_reviewer)):
    users_col = await get_collection("users")
    res = await users_col.delete_one({"_id": user_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"ok": True}

@app.get("/admin/stats")
async def admin_stats(_: None = Depends(_require_risk_reviewer)):
    users_col = await get_collection("users")
    total = await users_col.count_documents({})
    pending = await users_col.count_documents({"is_approved": False})
    admins = await users_col.count_documents({"role": "admin"})
    return {
        "total_users": total,
        "pending_approvals": pending,
        "admins": admins,
        "uptime": "99.9%" # Mock system stat
    }
    


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "providers": llm_router.available_providers(),
        "langgraph_structured": workflow is not None,
        "langgraph_analytics": analytics_workflow is not None,
    }


@app.get("/models")
def models() -> dict:
    return {
        "chat": {
            "default_provider": "ollama_local",  # can be changed on frontend per request
            "providers": llm_router.available_providers(),
            "model": settings.ollama_model,
            "ollama_base_url": settings.ollama_base_url,
        },
        "analytics": {
            "provider": "ollama_openai_compatible",
            "model_env_key": "OLLAMA_CHAT_MODEL",
            "default": settings.ollama_model,
        },
        "knowledge_base": {
            "embed_model": settings.ollama_embed_model,
            "postgres_configured": bool(settings.kb_pg_dsn),
            "pg_dsn_env_key": "KB_PG_DSN",
            "performance_defaults": {
                "fast_mode": settings.kb_fast_mode,
                "chunk_cap": settings.kb_chunk_cap,
                "skip_ner": settings.kb_skip_ner,
                "skip_pii": settings.kb_skip_pii,
                "skip_enrichment": settings.kb_skip_enrichment,
                "enrichment_batch_size": settings.kb_enrich_batch_size,
                "enrichment_workers": settings.kb_enrich_workers,
                "embedding_batch_size": settings.kb_embed_batch_size,
                "embedding_workers": settings.kb_embed_workers,
            },
        },
        "knowledge_graph": {
            "engine": "apache_age",
            "graph_name": settings.kb_age_graph_name,
            "pg_dsn_env_key": "KB_AGE_DSN",
            "pg_dsn_fallback_env_key": "KB_PG_DSN",
        },
        "orchestration": get_orchestration_status(),
        "auth": {
            "enabled": settings.api_auth_enabled,
            "mode": "header_api_key_rbac",
        },
    }


@app.get("/connectors")
def connectors() -> list[dict]:
    return list_connectors()


@app.post("/connectors/test", response_model=ConnectorTestResponse)
def connectors_test(req: ConnectorTestRequest, _: None = Depends(_require_data_scientist)) -> ConnectorTestResponse:
    try:
        result = test_connector(connector=req.connector, config=req.config)
        return ConnectorTestResponse(**result)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Connector test failed: {exc}") from exc


@app.post("/connectors/load", response_model=ConnectorLoadResponse)
def connectors_load(req: ConnectorLoadRequest, _: None = Depends(_require_data_scientist)) -> ConnectorLoadResponse:
    try:
        df = load_dataframe_from_connector(
            connector=req.connector,
            config=req.config,
            query=req.query,
            table=req.table,
            limit=req.limit,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Connector load failed: {exc}") from exc

    preview = df.head(100).replace({pd.NA: None}).to_dict(orient="records")
    return ConnectorLoadResponse(
        connector=req.connector,
        rows=int(len(df)),
        columns=[str(c) for c in df.columns],
        preview=preview,
    )


@app.get("/evaluation-tools")
def evaluation_tools() -> list[dict]:
    return list_eval_tools()


@app.post("/deepeval/run")
def deepeval_run(req: DeepEvalRequest) -> Dict[str, Any]:
    return run_deepeval(
        input_text=req.input_text,
        actual_output=req.actual_output,
        context=req.context,
        model_name=req.model_name,
        metrics=req.metrics,
    )


@app.post("/orchestrate", response_model=OrchestrateResponse)
async def orchestrate(
    file: UploadFile = File(...),
    business_problem: str = Form(""),
    target_column: str = Form(""),
    model_family: str = Form(""),
    fixed_model: str = Form(""),
    llm_provider: str = Form("bedrock"),
    preprocess_config: str = Form(""),
):
    try:
        payload = await file.read()
        df = load_dataframe_from_upload(file.filename, payload)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    try:
        preprocess_payload = json.loads(preprocess_config) if preprocess_config else None
        return _run_structured_pipeline(
            df=df,
            dataset_name=file.filename,
            business_problem=business_problem,
            target_column=target_column,
            model_family=model_family,
            fixed_model=fixed_model,
            llm_provider=_structured_provider(llm_provider),
            preprocess_config=preprocess_payload,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pipeline failed: {exc}") from exc


@app.post("/structured/preview", response_model=StructuredPreviewResponse)
async def structured_preview(file: UploadFile = File(...), _: None = Depends(_require_viewer)):
    payload = await file.read()
    df = load_dataframe_from_upload(file.filename, payload)
    head = df.head(200)
    return StructuredPreviewResponse(
        columns=[str(c) for c in head.columns.tolist()],
        rows=head.replace({pd.NA: None}).to_dict(orient="records"),
        shape={"rows": int(df.shape[0]), "columns": int(df.shape[1])},
    )


@app.post("/structured/tune", response_model=StructuredTuneResponse)
def structured_tune(req: StructuredTuneRequest, _: None = Depends(_require_data_scientist)):
    df = pd.DataFrame(req.rows)
    model_key = req.model_key
    result = run_optuna_tuning(df, target=req.target, task=req.task, model_key=model_key, n_trials=req.n_trials)
    return StructuredTuneResponse(**result)


@app.post("/structured/predict/train", response_model=StructuredPredictTrainResponse)
def structured_predict_train(req: StructuredPredictTrainRequest, _: None = Depends(_require_data_scientist)):
    df = pd.DataFrame(req.rows)
    model_key = req.model_key
    result = train_predictor(df, target=req.target, task=req.task, model_key=model_key)
    return StructuredPredictTrainResponse(**result)


@app.post("/structured/predict", response_model=StructuredPredictResponse)
def structured_predict(req: StructuredPredictRequest, _: None = Depends(_require_viewer)):
    result = predict_with_model(req.model_id, req.rows, return_proba=req.return_proba)
    return StructuredPredictResponse(**result)


@app.post("/structured/online/start", response_model=StructuredOnlineStartResponse)
def structured_online_start(req: StructuredOnlineStartRequest, _: None = Depends(_require_data_scientist)):
    result = start_stream(req.task)
    return StructuredOnlineStartResponse(**result)


@app.post("/structured/online/batch", response_model=StructuredOnlineBatchResponse)
def structured_online_batch(req: StructuredOnlineBatchRequest, _: None = Depends(_require_data_scientist)):
    result = process_stream_batch(req.stream_id, req.rows, target=req.target, max_rows=req.max_rows)
    return StructuredOnlineBatchResponse(**result)


@app.get("/structured/online/status", response_model=StructuredOnlineStatusResponse)
def structured_online_status(stream_id: str, _: None = Depends(_require_viewer)):
    result = get_stream_status(stream_id)
    return StructuredOnlineStatusResponse(**result)


@app.post("/structured/online/stop", response_model=StructuredOnlineStopResponse)
def structured_online_stop(stream_id: str, _: None = Depends(_require_data_scientist)):
    result = stop_stream(stream_id)
    return StructuredOnlineStopResponse(**result)


@app.post("/structured/explain", response_model=StructuredExplainResponse)
def structured_explain(req: StructuredExplainRequest, _: None = Depends(_require_viewer)):
    result = req.result or {}
    business_problem = req.business_problem or ""
    drift_context = req.drift_context or {}
    training = result.get("training", {}) if isinstance(result.get("training", {}), dict) else {}
    evaluation = result.get("evaluation", {}) if isinstance(result.get("evaluation", {}), dict) else {}
    validation = evaluation.get("validation", {}) if isinstance(evaluation.get("validation", {}), dict) else {}
    explainability = evaluation.get("explainability", {}) if isinstance(evaluation.get("explainability", {}), dict) else {}
    fairness = evaluation.get("fairness", {}) if isinstance(evaluation.get("fairness", {}), dict) else {}
    deployment = result.get("deployment", {}) if isinstance(result.get("deployment", {}), dict) else {}
    top_models = training.get("leaderboard", [])
    top_names = ", ".join([str(x.get("model")) for x in top_models[:6] if isinstance(x, dict)]) or str(training.get("best_model_name", "N/A"))

    # Keep prompt compact to reduce LLM latency.
    compact = {
        "problem_type": result.get("problem_type", "classification"),
        "champion": training.get("best_model_name", "N/A"),
        "best_score": float(training.get("best_score", 0.0)),
        "top_models": top_names,
        "holdout": validation.get("holdout_metrics", {}),
        "cv": validation.get("cv_metrics", {}),
        "nested_cv": validation.get("nested_cv_metrics", {}),
        "explainability": explainability,
        "fairness": fairness,
        "drift_context": drift_context,
    }

    prompt = (
        "You are a senior ML architect. Explain this run in practical terms for a Data Science user.\n"
        f"Business problem: {business_problem or 'Not provided'}\n"
        f"Summary data: {json.dumps(compact, default=str)}\n\n"
        "Output in 4 short sections:\n"
        "1) How models are solving the business problem\n"
        "2) Why champion is selected vs other top models\n"
        "3) SHAP/Fairness interpretation and limitations\n"
        "4) Hoeffding+ADWIN drift graph interpretation and what to do next\n"
        "Do not output JSON."
    )
    answer = llm_router.complete(prompt, provider=_structured_provider(req.llm_provider))
    return StructuredExplainResponse(explanation=answer)


@app.post("/structured/business-summary", response_model=StructuredBusinessSummaryResponse)
def structured_business_summary(req: StructuredBusinessSummaryRequest, _: None = Depends(_require_viewer)):
    result = req.result or {}
    training = result.get("training", {}) if isinstance(result.get("training", {}), dict) else {}
    evaluation = result.get("evaluation", {}) if isinstance(result.get("evaluation", {}), dict) else {}
    validation = evaluation.get("validation", {}) if isinstance(evaluation.get("validation", {}), dict) else {}
    holdout = validation.get("holdout_metrics", {}) if isinstance(validation.get("holdout_metrics", {}), dict) else {}
    cv = validation.get("cv_metrics", {}) if isinstance(validation.get("cv_metrics", {}), dict) else {}
    nested = validation.get("nested_cv_metrics", {}) if isinstance(validation.get("nested_cv_metrics", {}), dict) else {}

    problem = result.get("problem_type", "classification")
    champion = training.get("best_model_name", "N/A")
    score = float(training.get("best_score", 0.0))
    holdout_primary = float(holdout.get("f1_weighted", holdout.get("r2", 0.0)))
    summary = (
        f"Objective: {req.business_problem or 'Not provided'}\n"
        f"Detected task: {problem}\n"
        f"Champion model: {champion} with score {score:.4f}\n"
        f"Validation: Holdout {holdout_primary:.4f}, CV mean {float(cv.get('mean', 0.0)):.4f}, "
        f"Nested CV mean {float(nested.get('outer_mean', 0.0)):.4f}"
    )
    return StructuredBusinessSummaryResponse(summary=summary)


@app.post("/structured/explainability", response_model=StructuredExplainabilityResponse)
def structured_explainability(req: StructuredExplainabilityRequest, _: None = Depends(_require_data_scientist)):
    df = pd.DataFrame(req.rows)
    out = run_explainability(df, target=req.target, task=req.task, model_key=req.model_key, top_n=req.top_n)
    return StructuredExplainabilityResponse(explainability=out)

 
@app.post("/orchestrate-from-connector", response_model=OrchestrateResponse)
def orchestrate_from_connector(
    req: ConnectorOrchestrateRequest,
    _: None = Depends(_require_data_scientist),
):
    try:
        df = load_dataframe_from_connector(
            connector=req.connector,
            config=req.config,
            query=req.query,
            table=req.table,
            limit=req.limit,
        )
        dataset_name = req.dataset_name or req.table or req.connector
        return _run_structured_pipeline(
            df=df,
            dataset_name=dataset_name,
            business_problem=req.business_problem,
            target_column=req.target_column,
            model_family=req.model_family,
            fixed_model=req.fixed_model,
            llm_provider=_structured_provider(req.llm_provider),
            preprocess_config=req.preprocess_config,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Connector orchestrate failed: {exc}") from exc


@app.get("/orchestration/status")
def orchestration_status() -> Dict[str, Any]:
    return get_orchestration_status()


@app.get("/registry/models")
def registry_list(_: None = Depends(_require_viewer)) -> Dict[str, Any]:
    return {"models": registry.list_models()}


@app.post("/registry/approve")
def registry_approve(req: RegistryApproveRequest, _: None = Depends(_require_risk_reviewer)) -> Dict[str, Any]:
    out = registry.approve(model_id=req.model_id, approver=req.approver, note=req.note)
    if not out.get("ok"):
        raise HTTPException(status_code=404, detail=str(out))
    return out


@app.post("/registry/promote")
def registry_promote(req: RegistryPromoteRequest, _: None = Depends(_require_approver)) -> Dict[str, Any]:
    out = registry.promote(model_id=req.model_id, stage=req.stage, actor=req.actor)
    if not out.get("ok"):
        raise HTTPException(status_code=400, detail=str(out))
    return out


@app.post("/registry/rollback")
def registry_rollback(req: RegistryRollbackRequest, _: None = Depends(_require_approver)) -> Dict[str, Any]:
    out = registry.rollback_to(model_id=req.model_id, actor=req.actor)
    if not out.get("ok"):
        raise HTTPException(status_code=400, detail=str(out))
    return out


@app.get("/feature-store/tables")
def feature_store_tables(_: None = Depends(_require_viewer)) -> Dict[str, Any]:
    return feature_store.list_tables()


@app.post("/feature-store/offline/upsert")
def feature_store_upsert(req: FeatureStoreUpsertRequest, _: None = Depends(_require_data_scientist)) -> Dict[str, Any]:
    return feature_store.upsert_offline(table=req.table, rows=req.rows)


@app.post("/feature-store/online/materialize")
def feature_store_materialize(req: FeatureStoreMaterializeRequest, _: None = Depends(_require_ml_engineer)) -> Dict[str, Any]:
    return feature_store.materialize_online(table=req.table, key_col=req.key_col, ts_col=req.ts_col)


@app.post("/feature-store/online/read")
def feature_store_read(req: FeatureStoreReadRequest, _: None = Depends(_require_viewer)) -> Dict[str, Any]:
    return feature_store.read_online(table=req.table, key_col=req.key_col, key_val=req.key_val)


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    prompt = f"""
You are an AI Scientist.
Question: {req.question}
Context: {req.context or 'N/A'}
Respond in concise technical language.
"""
    answer = llm_router.complete(prompt, provider=req.provider)
    return ChatResponse(answer=answer)


@app.post("/chat/structured-file", response_model=ChatResponse)
async def chat_structured_file(
    file: UploadFile = File(...),
    question: str = Form(...),
    provider: str = Form("bedrock"),
) -> ChatResponse:
    payload = await file.read()
    df = load_dataframe_from_upload(file.filename, payload)
    head = df.head(20).replace({pd.NA: None}).to_dict(orient="records")
    summary = {
        "rows": int(df.shape[0]),
        "columns": [str(c) for c in df.columns],
        "dtypes": {str(c): str(t) for c, t in df.dtypes.items()},
        "sample": head,
    }
    prompt = (
        "You are a data analyst. Answer the user's question using the structured dataset summary below.\n"
        "If the question cannot be answered from the summary, say what is missing.\n\n"
        f"Question: {question}\n"
        f"Dataset summary: {json.dumps(summary, default=str)}"
    )
    answer = llm_router.complete(prompt, provider=provider)
    return ChatResponse(answer=answer)


@app.post("/kb/build", response_model=KBBuildResponse)
async def kb_build(
    file: UploadFile = File(...),
    dataset_id: str = Form(""),
    llm_provider: str = Form("bedrock"),
    fast_mode: bool = Form(False),
    chunk_cap: int = Form(200),
    skip_ner: bool = Form(False),
    skip_pii: bool = Form(False),
    skip_enrichment: bool = Form(False),
    enrichment_batch_size: int = Form(8),
    enrichment_workers: int = Form(2),
    embedding_batch_size: int = Form(32),
    embedding_workers: int = Form(2),
):
    try:
        payload = await file.read()
        out = kb_service.build_from_bytes(
            filename=file.filename,
            payload=payload,
            dataset_id=dataset_id or file.filename,
            llm_provider=llm_provider,
            fast_mode=fast_mode,
            chunk_cap=chunk_cap,
            skip_ner=skip_ner,
            skip_pii=skip_pii,
            skip_enrichment=skip_enrichment,
            enrichment_batch_size=enrichment_batch_size,
            enrichment_workers=enrichment_workers,
            embedding_batch_size=embedding_batch_size,
            embedding_workers=embedding_workers,
        )
        return KBBuildResponse(**out)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Knowledge base build failed: {exc}") from exc


@app.post("/kb/query", response_model=KBQueryResponse)
def kb_query(req: KBQueryRequest) -> KBQueryResponse:
    try:
        out = kb_service.query(
            dataset_id=req.dataset_id,
            query=req.query,
            top_k=req.top_k,
            llm_provider=req.llm_provider,
        )
        return KBQueryResponse(**out)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Knowledge base query failed: {exc}") from exc


@app.post("/kg/build", response_model=KGBuildResponse)
def kg_build(req: KGBuildRequest) -> KGBuildResponse:
    try:
        result = kg_service.build_for_dataset(req.dataset_id)
        return KGBuildResponse(
            dataset_id=result.dataset_id,
            graph_name=result.graph_name,
            chunks=result.chunks,
            entities=result.entities,
            edges=result.edges,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Knowledge graph build failed: {exc}") from exc


@app.post("/kg/query", response_model=KGQueryResponse)
def kg_query(req: KGQueryRequest) -> KGQueryResponse:
    try:
        result = kg_service.query_neighbors(
            dataset_id=req.dataset_id,
            entity=req.entity,
            limit=req.limit,
        )
        return KGQueryResponse(**result)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Knowledge graph query failed: {exc}") from exc


@app.post("/kg/subgraph", response_model=KGSubgraphResponse)
def kg_subgraph(req: KGSubgraphRequest) -> KGSubgraphResponse:
    try:
        result = kg_service.subgraph(
            dataset_id=req.dataset_id,
            seed_entity=req.seed_entity,
            hops=req.hops,
            limit=req.limit,
        )
        return KGSubgraphResponse(**result)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Knowledge graph subgraph failed: {exc}") from exc


@app.post("/analytics/query", response_model=AnalyticsQueryResponse)
def analytics_query(req: AnalyticsQueryRequest) -> AnalyticsQueryResponse:
    try:
        df = pd.DataFrame(req.dataframe)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid dataframe payload: {exc}") from exc

    if _is_distribution_means_query(req.query):
        payload = _distribution_means_query_payload(df, req.query)
        return AnalyticsQueryResponse(
            should_plot=bool(payload.get("should_plot", False)),
            code=str(payload.get("code", "")),
            execution=payload.get("execution", {}),
            reasoning=str(payload.get("reasoning", "")),
        )
    if _is_simple_distribution_query(req.query):
        payload = _simple_distribution_query_payload(df, req.query)
        return AnalyticsQueryResponse(
            should_plot=bool(payload.get("should_plot", False)),
            code=str(payload.get("code", "")),
            execution=payload.get("execution", {}),
            reasoning=str(payload.get("reasoning", "")),
        )
    if _is_pair_separation_query(req.query):
        payload = _pair_separation_query_payload(df, req.query)
        return AnalyticsQueryResponse(
            should_plot=bool(payload.get("should_plot", False)),
            code=str(payload.get("code", "")),
            execution=payload.get("execution", {}),
            reasoning=str(payload.get("reasoning", "")),
        )

    state: AgentState = {
        "dataframe": df,
        "analytics_query": req.query,
        "analytics_chat_context": req.chat_context or "",
        "llm_provider": req.llm_provider or "ollama_local",
        "analytics_force_sql": bool(req.force_sql),
        "warnings": [],
    }

    try:
        final_state = (
            analytics_workflow.invoke(state)
            if analytics_workflow
            else run_analytics_sequential_fallback(state)
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Analytics pipeline failed: {exc}") from exc

    return AnalyticsQueryResponse(
        should_plot=bool(final_state.get("analytics_should_plot", False)),
        code=str(final_state.get("analytics_code", "")),
        execution=final_state.get("analytics_execution", {}),
        reasoning=str(final_state.get("analytics_reasoning", "")),
    )


@app.post("/analytics/nl-to-sql", response_model=AnalyticsNLToSQLResponse)
def analytics_nl_to_sql(req: AnalyticsNLToSQLRequest) -> AnalyticsNLToSQLResponse:
    try:
        df = pd.DataFrame(req.dataframe)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid dataframe payload: {exc}") from exc

    cols = ", ".join(df.columns.tolist())
    sql = ""
    if dspy_ready():
        sql = dspy_nl_to_sql(req.query, df.columns.tolist(), table_name="data")
    if not sql:
        instruction = (
            f"You are a SQL generator. Table name is data. Columns: {cols}. "
            f"Write a single DuckDB SQL query to answer: '{req.query}'. "
            "Return only SQL without markdown."
        )
        try:
            cfg = AnalyticsModelConfig()
            sql = chat_complete(
                prompt=instruction,
                temperature=0.0,
                max_tokens=512,
                trace_name="analytics_nl_to_sql",
            ).strip()
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Analytics NL->SQL failed: {exc}") from exc

    sql = _extract_sql(sql) or "SELECT * FROM data LIMIT 100;"
    return AnalyticsNLToSQLResponse(sql=sql)


@app.post("/analytics/sql-explain", response_model=AnalyticsSQLExplainResponse)
def analytics_sql_explain(req: AnalyticsSQLExplainRequest) -> AnalyticsSQLExplainResponse:
    sql = (req.sql or "").strip()
    if not sql:
        raise HTTPException(status_code=400, detail="SQL is required")

    prompt = (
        "You are a data analyst. Explain the following SQL in plain English.\n"
        "Focus on what it returns (grouping, filtering, aggregation). Keep it concise.\n\n"
        f"SQL:\n{sql}"
    )
    explanation = llm_router.complete(prompt, provider=req.llm_provider or "bedrock")
    return AnalyticsSQLExplainResponse(explanation=explanation)


@app.post("/analytics/run-sql", response_model=AnalyticsSQLResponse)
def analytics_run_sql(req: AnalyticsSQLRequest) -> AnalyticsSQLResponse:
    try:
        df = pd.DataFrame(req.dataframe)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid dataframe payload: {exc}") from exc

    sql = (req.sql or "").strip()
    if not sql:
        raise HTTPException(status_code=400, detail="SQL is required")

    try:
        con = duckdb.connect(database=":memory:")
        con.register("data", df)
        result_df = con.execute(sql).df()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"SQL execution failed: {exc}") from exc

    rows = result_df.replace({pd.NA: None}).to_dict(orient="records")
    return AnalyticsSQLResponse(
        rows=rows,
        columns=[str(c) for c in result_df.columns],
        row_count=int(len(result_df)),
    )


@app.post("/analytics/query-file", response_model=AnalyticsQueryResponse)
async def analytics_query_file(
    file: UploadFile = File(...),
    query: str = Form(...),
    chat_context: str = Form(""),
    llm_provider: str = Form("bedrock"),
    force_sql: bool = Form(False),
):
    try:
        payload = await file.read()
        df = load_dataframe_from_upload(file.filename, payload)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid file payload: {exc}") from exc

    if _is_distribution_means_query(query):
        payload = _distribution_means_query_payload(df, query)
        return AnalyticsQueryResponse(
            should_plot=bool(payload.get("should_plot", False)),
            code=str(payload.get("code", "")),
            execution=payload.get("execution", {}),
            reasoning=str(payload.get("reasoning", "")),
        )
    if _is_simple_distribution_query(query):
        payload = _simple_distribution_query_payload(df, query)
        return AnalyticsQueryResponse(
            should_plot=bool(payload.get("should_plot", False)),
            code=str(payload.get("code", "")),
            execution=payload.get("execution", {}),
            reasoning=str(payload.get("reasoning", "")),
        )
    if _is_pair_separation_query(query):
        payload = _pair_separation_query_payload(df, query)
        return AnalyticsQueryResponse(
            should_plot=bool(payload.get("should_plot", False)),
            code=str(payload.get("code", "")),
            execution=payload.get("execution", {}),
            reasoning=str(payload.get("reasoning", "")),
        )

    state: AgentState = {
        "dataframe": df,
        "analytics_query": query,
        "analytics_chat_context": chat_context,
        "llm_provider": llm_provider,
        "analytics_force_sql": bool(force_sql),
        "warnings": [],
    }

    try:
        final_state = (
            analytics_workflow.invoke(state)
            if analytics_workflow
            else run_analytics_sequential_fallback(state)
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Analytics pipeline failed: {exc}") from exc

    return AnalyticsQueryResponse(
        should_plot=bool(final_state.get("analytics_should_plot", False)),
        code=str(final_state.get("analytics_code", "")),
        execution=final_state.get("analytics_execution", {}),
        reasoning=str(final_state.get("analytics_reasoning", "")),
    )


@app.post("/analytics/insights", response_model=AnalyticsInsightsResponse)
def analytics_insights(req: AnalyticsInsightsRequest) -> AnalyticsInsightsResponse:
    try:
        df = pd.DataFrame(req.dataframe)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid dataframe payload: {exc}") from exc

    state: AgentState = {"dataframe": df, "llm_provider": req.llm_provider, "warnings": []}
    try:
        final_state = run_analytics_insights(state)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Analytics insights failed: {exc}") from exc

    return AnalyticsInsightsResponse(insights=str(final_state.get("analytics_insights", "")))


@app.post("/analytics/dashboard", response_model=AnalyticsDashboardResponse)
def analytics_dashboard(req: AnalyticsDashboardRequest) -> AnalyticsDashboardResponse:
    try:
        df = pd.DataFrame(req.dataframe)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid dataframe payload: {exc}") from exc
    out = build_dashboard_stats(df)
    return AnalyticsDashboardResponse(**out)


@app.post("/analytics/insights-file", response_model=AnalyticsInsightsResponse)
async def analytics_insights_file(
    file: UploadFile = File(...),
    llm_provider: str = Form("bedrock"),
):
    try:
        payload = await file.read()
        df = load_dataframe_from_upload(file.filename, payload)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid file payload: {exc}") from exc

    state: AgentState = {"dataframe": df, "llm_provider": llm_provider, "warnings": []}
    try:
        final_state = run_analytics_insights(state)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Analytics insights failed: {exc}") from exc

    return AnalyticsInsightsResponse(insights=str(final_state.get("analytics_insights", "")))


@app.post("/analytics/visuals-file", response_model=AnalyticsVisualsResponse)
async def analytics_visuals_file(
    file: UploadFile = File(...),
):
    try:
        payload = await file.read()
        df = load_dataframe_from_upload(file.filename, payload)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid file payload: {exc}") from exc

    visuals = generate_visual_pack(df)
    return AnalyticsVisualsResponse(visuals=visuals)


@app.post("/analytics/run-file-stream")
async def analytics_run_file_stream(
    file: UploadFile = File(...),
    query: str = Form(...),
    chat_context: str = Form(""),
    llm_provider: str = Form("ollama_local"),
):
    try:
        payload = await file.read()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid file payload: {exc}") from exc

    def event_stream():
        yield _json_line("status", message="Loading dataset")
        try:
            df = load_dataframe_from_upload(file.filename, payload)
        except Exception as exc:
            yield _json_line("error", message=f"Invalid file payload: {exc}")
            return

        if _is_distribution_means_query(query):
            yield _json_line("status", message="Running deterministic analytics plan")
            query_payload = _distribution_means_query_payload(df, query)
        elif _is_simple_distribution_query(query):
            yield _json_line("status", message="Running deterministic distribution plan")
            query_payload = _simple_distribution_query_payload(df, query)
        elif _is_pair_separation_query(query):
            yield _json_line("status", message="Running deterministic pair-separation plan")
            query_payload = _pair_separation_query_payload(df, query)
        else:
            state: AgentState = {
                "dataframe": df,
                "analytics_query": query,
                "analytics_chat_context": chat_context,
                "llm_provider": llm_provider,
                "warnings": [],
            }
            yield _json_line("status", message="Running analytics query workflow")
            try:
                final_state = (
                    analytics_workflow.invoke(state)
                    if analytics_workflow
                    else run_analytics_sequential_fallback(state)
                )
            except Exception as exc:
                yield _json_line("error", message=f"Analytics pipeline failed: {exc}")
                return
            query_payload = {
                "should_plot": bool(final_state.get("analytics_should_plot", False)),
                "code": str(final_state.get("analytics_code", "")),
                "execution": final_state.get("analytics_execution", {}),
                "reasoning": str(final_state.get("analytics_reasoning", "")),
            }

        reasoning = str(query_payload.get("reasoning", "") or "")
        if reasoning:
            yield _json_line("status", message="Streaming reasoning")
            words = reasoning.split(" ")
            chunk: list[str] = []
            for idx, word in enumerate(words, start=1):
                chunk.append(word)
                if idx % 8 == 0 or idx == len(words):
                    yield _json_line("reasoning_chunk", text=(" ".join(chunk) + " "))
                    chunk = []

        yield _json_line("status", message="Generating dataset insights")
        try:
            insight_state = run_analytics_insights(
                {
                    "dataframe": df,
                    "analytics_query": query,
                    "llm_provider": llm_provider,
                    "warnings": [],
                }
            )
            insights_payload = {"insights": str(insight_state.get("analytics_insights", ""))}
        except Exception as exc:
            insights_payload = {"insights": f"Insights unavailable: {exc}"}

        yield _json_line("status", message="Generating visual pack")
        try:
            visuals_payload = {"visuals": generate_visual_pack(df)}
        except Exception as exc:
            visuals_payload = {"visuals": [], "error": str(exc)}

        yield _json_line(
            "result",
            payload={
                "query": query_payload,
                "insights": insights_payload,
                "visuals": visuals_payload,
            },
        )
        yield _json_line("done", message="Analytics completed")

    return StreamingResponse(event_stream(), media_type="application/x-ndjson")


@app.post("/unstructured/analyze", response_model=UnstructuredAnalyzeResponse)
async def unstructured_analyze(file: UploadFile = File(...)) -> Dict[str, Any]:
    try:
        payload = await file.read()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid file payload: {exc}") from exc

    try:
        return analyze_unstructured(file.filename, payload)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Unstructured analyze failed: {exc}") from exc


@app.post("/transform/run", response_model=TransformationResponse)
async def transform_run(
    transform_type: str = Form(...),
    file: UploadFile = File(...),
    _: None = Depends(_require_viewer),
):
    try:
        payload = await file.read()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid file payload: {exc}") from exc

    try:
        out_name, media_type, content = run_transformation(file.filename, payload, transform_type)
        return TransformationResponse(
            file_name=out_name,
            media_type=media_type,
            content_base64=content,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Transformation failed: {exc}") from exc


@app.post("/edgequake/upload", response_model=EdgeQuakeUploadResponse)
async def edgequake_upload(
    base_url: str = Form("http://localhost:8080"),
    file: UploadFile = File(...),
    _: None = Depends(_require_viewer),
):
    try:
        payload = await file.read()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid file payload: {exc}") from exc
    try:
        resp = requests.post(
            f"{base_url.rstrip('/')}/api/v1/documents/upload",
            files={"file": (file.filename, payload)},
            timeout=120,
        )
        resp.raise_for_status()
        return EdgeQuakeUploadResponse(data=resp.json())
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"EdgeQuake upload failed: {exc}") from exc


@app.post("/edgequake/query", response_model=EdgeQuakeQueryResponse)
def edgequake_query(req: EdgeQuakeQueryRequest, _: None = Depends(_require_viewer)):
    try:
        resp = requests.post(
            f"{req.base_url.rstrip('/')}/api/v1/query",
            json={"query": req.query, "mode": req.mode},
            timeout=120,
        )
        resp.raise_for_status()
        return EdgeQuakeQueryResponse(data=resp.json())
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"EdgeQuake query failed: {exc}") from exc
