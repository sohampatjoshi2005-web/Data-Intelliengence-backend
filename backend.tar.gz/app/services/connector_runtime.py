from __future__ import annotations

from typing import Any, Dict, Optional

import pandas as pd
import requests

try:
    from sqlalchemy import create_engine, text
except Exception:
    create_engine = None
    text = None


def _require_sqlalchemy() -> None:
    if create_engine is None or text is None:
        raise RuntimeError("sqlalchemy is not installed")


def _normalize_connector(connector: str) -> str:
    key = connector.lower().strip()
    aliases = {
        "rest api": "rest_api",
        "postgresql": "postgres",
        "postgre sql": "postgres",
        "sql": "sql",
        "generic sql": "sql",
        "microsoft sql server": "sql",
        "spark": "apache_spark",
        "spark sql": "apache_spark",
        "apache spark": "apache_spark",
        "apache spark sql": "apache_spark",
    }
    return aliases.get(key, key)


def _build_postgres_url(config: Dict[str, Any]) -> str:
    if config.get("url"):
        return str(config["url"])
    if config.get("sqlalchemy_url"):
        return str(config["sqlalchemy_url"])
    if config.get("dsn"):
        return str(config["dsn"])

    required = ("host", "database", "username", "password")
    missing = [k for k in required if not config.get(k)]
    if missing:
        raise ValueError(
            "PostgreSQL config requires either url/sqlalchemy_url/dsn or "
            "host, database, username, password"
        )
    host = config["host"]
    port = int(config.get("port", 5432))
    database = config["database"]
    username = config["username"]
    password = config["password"]
    driver = config.get("driver", "postgresql+psycopg2")
    return f"{driver}://{username}:{password}@{host}:{port}/{database}"


def _sqlalchemy_url(connector: str, config: Dict[str, Any]) -> str:
    if connector == "sqlite":
        return f"sqlite:///{config['path']}"
    if connector == "postgres":
        return _build_postgres_url(config)
    if connector in {"sql", "apache_spark"}:
        url = config.get("url") or config.get("sqlalchemy_url") or config.get("jdbc_url")
        if not url:
            raise ValueError("config.url (or sqlalchemy_url/jdbc_url) is required")
        return str(url)
    raise ValueError(f"Unsupported SQL connector: {connector}")


def test_connector(connector: str, config: Dict[str, Any]) -> Dict[str, Any]:
    connector = _normalize_connector(connector)

    if connector in {"sqlite", "postgres", "sql", "apache_spark"}:
        _require_sqlalchemy()
        url = _sqlalchemy_url(connector, config)
        engine = create_engine(url)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"ok": True, "connector": connector, "message": "connection successful"}

    if connector == "rest_api":
        url = config.get("url")
        headers = config.get("headers", {})
        if not url:
            raise ValueError("url is required for REST API connector")
        resp = requests.get(url, headers=headers, timeout=20)
        return {
            "ok": resp.ok,
            "connector": connector,
            "status_code": resp.status_code,
            "message": "reachable" if resp.ok else f"http error {resp.status_code}",
        }

    raise ValueError(f"Unsupported connector: {connector}")


def load_dataframe_from_connector(
    connector: str,
    config: Dict[str, Any],
    query: Optional[str] = None,
    table: Optional[str] = None,
    limit: int = 1000,
) -> pd.DataFrame:
    connector = _normalize_connector(connector)
    limit = max(1, min(int(limit), 100000))

    if connector in {"sqlite", "postgres", "sql", "apache_spark"}:
        _require_sqlalchemy()
        url = _sqlalchemy_url(connector, config)
        engine = create_engine(url)

        if query:
            sql = query
        elif table:
            sql = f"SELECT * FROM {table} LIMIT {limit}"
        else:
            raise ValueError("Either query or table is required for SQL connectors")

        with engine.connect() as conn:
            df = pd.read_sql(text(sql), conn)
        return df

    if connector == "rest_api":
        url = config.get("url")
        method = config.get("method", "GET").upper()
        headers = config.get("headers", {})
        params = config.get("params", {})
        body = config.get("body", None)
        root_key = config.get("root_key", "")
        if not url:
            raise ValueError("url is required for REST API connector")

        resp = requests.request(method=method, url=url, headers=headers, params=params, json=body, timeout=30)
        resp.raise_for_status()
        payload = resp.json()

        data = payload
        if root_key:
            for part in root_key.split("."):
                if isinstance(data, dict):
                    data = data.get(part, [])
                else:
                    data = []
                    break

        if isinstance(data, list):
            return pd.json_normalize(data)
        if isinstance(data, dict):
            return pd.json_normalize([data])
        return pd.DataFrame({"value": [data]})

    raise ValueError(f"Unsupported connector: {connector}")
