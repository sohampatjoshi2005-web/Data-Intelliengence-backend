import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

class EmailService:
    @staticmethod
    def send_email(to_email: str, subject: str, body_markdown: str):
        if not settings.email_enabled:
            logger.info(f"Email service disabled. Would have sent '{subject}' to {to_email}")
            return False

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{settings.email_display_name} <{settings.email_from}>"
            msg["To"] = to_email

            # Professional HTML Template Wrapper
            formatted_body = body_markdown.replace('\n', '<br>')
            html_body = f"""
            <html>
                <body style="font-family: 'Inter', sans-serif; line-height: 1.6; color: #1a1a1a; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
                    <div style="background: #f9f9f9; padding: 40px; border-radius: 24px; border: 1px solid #eaeaea;">
                        <h2 style="font-size: 24px; font-weight: 800; margin-bottom: 24px; color: #000;">{subject}</h2>
                        <div style="font-size: 16px; color: #444;">
                            {formatted_body}
                        </div>
                        <div style="margin-top: 40px; padding-top: 24px; border-top: 1px solid #eaeaea; font-size: 12px; color: #999; text-transform: uppercase; letter-spacing: 0.1em;">
                            Sent from the Superhumanly Governance System
                        </div>
                    </div>
                </body>
            </html>
            """
            
            msg.attach(MIMEText(body_markdown, "plain"))
            msg.attach(MIMEText(html_body, "html"))

            with smtplib.SMTP(settings.smtp_server, settings.smtp_port) as server:
                server.starttls()
                server.login(settings.smtp_username, settings.smtp_password)
                server.send_message(msg)
            
            logger.info(f"Email successfully sent to {to_email}")
            return True
        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {str(e)}")
            return False

    @staticmethod
    def notify_registration_received(email: str):
        subject = "Access Request Received"
        body = f"Hello,\\n\\nYour request for access to the Superhumanly Thoughts platform has been received and is currently under review by our governance team.\\n\\nYou will receive another notification once your credentials have been verified and access is granted."
        return EmailService.send_email(email, subject, body)

    @staticmethod
    def notify_access_approved(email: str, role: str):
        subject = "Superhumanly Access Granted"
        body = f"Congratulations,\\n\\nYour access request has been approved. You have been granted the role of **{role.upper()}**.\\n\\nYou can now log in to the Sovereign Workspace to begin your intelligence session."
        return EmailService.send_email(email, subject, body)

    @staticmethod
    def notify_access_denied(email: str):
        subject = "Access Request Update"
        body = f"Hello,\\n\\nFollowing a governance review, your access to the Superhumanly platform has been revoked or denied at this time.\\n\\nIf you believe this is an error, please contact your system administrator."
        return EmailService.send_email(email, subject, body)
