from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    r2_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import KFold, StratifiedKFold, train_test_split


@dataclass
class ValidationResult:
    holdout_metrics: Dict[str, Any]
    cv_metrics: Dict[str, Any]
    nested_cv_metrics: Dict[str, Any]
    threshold_tuning: Dict[str, Any]
    calibration: Dict[str, Any]


def _split(df: pd.DataFrame, target: str, problem: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    X = df.drop(columns=[target])
    y = df[target]
    stratify = None
    if problem == "classification" and y.nunique(dropna=False) > 1:
        vc = y.value_counts(dropna=False)
        if not vc.empty and int(vc.min()) >= 2:
            stratify = y
    return train_test_split(X, y, test_size=0.2, random_state=42, stratify=stratify)


def _classification_metrics(y_true: pd.Series, y_pred: np.ndarray, y_prob: np.ndarray | None = None) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "f1_weighted": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "precision_weighted": float(precision_score(y_true, y_pred, average="weighted", zero_division=0)),
        "recall_weighted": float(recall_score(y_true, y_pred, average="weighted", zero_division=0)),
    }
    if y_prob is not None:
        try:
            if y_prob.ndim == 2 and y_prob.shape[1] > 1:
                out["auc_ovr_weighted"] = float(roc_auc_score(y_true, y_prob, multi_class="ovr", average="weighted"))
            else:
                out["auc"] = float(roc_auc_score(y_true, y_prob))
        except Exception:
            pass
    return out


def _regression_metrics(y_true: pd.Series, y_pred: np.ndarray) -> Dict[str, Any]:
    return {
        "r2": float(r2_score(y_true, y_pred)),
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
    }


def _fit_predict(model: Any, X_train: pd.DataFrame, y_train: pd.Series, X_test: pd.DataFrame):
    est = clone(model)
    est.fit(X_train, y_train)
    preds = est.predict(X_test)
    prob = None
    if hasattr(est, "predict_proba"):
        try:
            prob = est.predict_proba(X_test)
        except Exception:
            prob = None
    return est, preds, prob


def _threshold_tuning_binary(y_true: pd.Series, y_prob: np.ndarray | None) -> Dict[str, Any]:
    if y_prob is None:
        return {"enabled": False, "reason": "predict_proba unavailable"}
    if getattr(y_prob, "ndim", 1) != 2 or y_prob.shape[1] != 2:
        return {"enabled": False, "reason": "not binary classification"}

    probs = y_prob[:, 1]
    best_thr = 0.5
    best_f1 = -1.0
    for thr in np.linspace(0.05, 0.95, 19):
        y_hat = (probs >= thr).astype(int)
        try:
            score = float(f1_score(y_true, y_hat, zero_division=0))
        except Exception:
            continue
        if score > best_f1:
            best_f1 = score
            best_thr = float(thr)
    return {
        "enabled": True,
        "best_threshold": best_thr,
        "best_f1": best_f1,
        "default_threshold": 0.5,
    }


def _calibration_binary(y_true: pd.Series, y_prob: np.ndarray | None) -> Dict[str, Any]:
    if y_prob is None or getattr(y_prob, "ndim", 1) != 2 or y_prob.shape[1] != 2:
        return {"enabled": False, "reason": "binary probabilities unavailable"}
    probs = y_prob[:, 1]
    try:
        brier = float(brier_score_loss(y_true, probs))
    except Exception:
        brier = None
    return {
        "enabled": True,
        "brier_score": brier,
    }


def evaluate_model(df: pd.DataFrame, target: str, problem: str, model: Any) -> ValidationResult:
    X_train, X_test, y_train, y_test = _split(df, target, problem)
    fitted, preds, prob = _fit_predict(model, X_train, y_train, X_test)

    if problem == "classification":
        holdout = _classification_metrics(y_test, preds, prob)
        threshold = _threshold_tuning_binary(y_test, prob)
        calibration = _calibration_binary(y_test, prob)
        splitter = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        score_name = "f1_weighted"
    else:
        holdout = _regression_metrics(y_test, preds)
        threshold = {"enabled": False, "reason": "regression task"}
        calibration = {"enabled": False, "reason": "regression task"}
        splitter = KFold(n_splits=5, shuffle=True, random_state=42)
        score_name = "r2"

    # CV metrics with manual loop for robust handling of pipelines.
    cv_scores: list[float] = []
    X_all = df.drop(columns=[target])
    y_all = df[target]
    for tr_idx, te_idx in splitter.split(X_all, y_all):
        Xtr, Xte = X_all.iloc[tr_idx], X_all.iloc[te_idx]
        ytr, yte = y_all.iloc[tr_idx], y_all.iloc[te_idx]
        _, p, _ = _fit_predict(model, Xtr, ytr, Xte)
        if problem == "classification":
            cv_scores.append(float(f1_score(yte, p, average="weighted", zero_division=0)))
        else:
            cv_scores.append(float(r2_score(yte, p)))

    cv_metrics = {
        "metric": score_name,
        "mean": float(np.mean(cv_scores)) if cv_scores else None,
        "std": float(np.std(cv_scores)) if cv_scores else None,
        "n_splits": 5,
    }

    # Lightweight nested CV approximation: outer 3 folds, inner model fit on each outer train.
    outer_splitter = StratifiedKFold(n_splits=3, shuffle=True, random_state=42) if problem == "classification" else KFold(n_splits=3, shuffle=True, random_state=42)
    outer_scores: list[float] = []
    for tr_idx, te_idx in outer_splitter.split(X_all, y_all):
        Xtr, Xte = X_all.iloc[tr_idx], X_all.iloc[te_idx]
        ytr, yte = y_all.iloc[tr_idx], y_all.iloc[te_idx]
        est = clone(model)
        est.fit(Xtr, ytr)
        pred = est.predict(Xte)
        if problem == "classification":
            outer_scores.append(float(f1_score(yte, pred, average="weighted", zero_division=0)))
        else:
            outer_scores.append(float(r2_score(yte, pred)))

    nested = {
        "metric": score_name,
        "outer_mean": float(np.mean(outer_scores)) if outer_scores else None,
        "outer_std": float(np.std(outer_scores)) if outer_scores else None,
        "outer_folds": 3,
    }

    _ = fitted
    return ValidationResult(
        holdout_metrics=holdout,
        cv_metrics=cv_metrics,
        nested_cv_metrics=nested,
        threshold_tuning=threshold,
        calibration=calibration,
    )
