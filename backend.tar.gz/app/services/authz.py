from __future__ import annotations
import os
from typing import Optional
from fastapi import Header, HTTPException, Depends
from app.services.auth_service import decode_access_token
from app.models.user import TokenData

# Simplified roles
ROLE_ORDER = {
    "business/analyst": 0,
    "data scientist": 1,
    "admin": 2,
}

def auth_enabled() -> bool:
    # We'll enable it by default now that we have a real system
    return os.getenv("API_AUTH_ENABLED", "true").lower() == "true"

def get_current_user_role(authorization: Optional[str] = Header(None)) -> str:
    if not auth_enabled():
        return "admin" # Bypass if disabled
    
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization header")
    
    token = authorization.replace("Bearer ", "")
    token_data = decode_access_token(token)
    
    if not token_data:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    
    return token_data.role

def require_role(min_role: str, role: str) -> None:
    if not auth_enabled():
        return

    user_role_val = ROLE_ORDER.get(role, -1)
    min_role_val = ROLE_ORDER.get(min_role, 999)
    
    if user_role_val < min_role_val:
        raise HTTPException(status_code=403, detail=f"Forbidden: {min_role} role required")
