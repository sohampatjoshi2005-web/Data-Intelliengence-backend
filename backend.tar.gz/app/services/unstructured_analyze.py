from __future__ import annotations

import base64
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
import requests

from app.services.unstructured_processing import convert_to_markdown, save_temp_upload
from app.core.config import settings

try:
    from unstructured.partition.auto import partition
except Exception:
    partition = None

try:
    import pytesseract
    from PIL import Image
except Exception:
    pytesseract = None
    Image = None

try:
    import ffmpeg
except Exception:
    ffmpeg = None

try:
    import spacy
except Exception:
    spacy = None


DOC_EXTS = {".pdf", ".docx", ".pptx", ".xlsx", ".txt", ".md", ".html", ".htm", ".json", ".csv"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".gif"}
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".avi"}
OLLAMA_VISION_BASE_URL = settings.ollama_vision_base_url.rstrip("/")
OLLAMA_VISION_MODEL = os.getenv("OLLAMA_VISION_MODEL", "moondream")
OLLAMA_VISION_PROMPT = os.getenv("OLLAMA_VISION_PROMPT", "Describe this image in detail.")
OLLAMA_VISION_TIMEOUT = int(os.getenv("OLLAMA_VISION_TIMEOUT", "300"))
SKIP_OCR = os.getenv("UNSTRUCTURED_SKIP_OCR", "false").lower() == "true"


def _load_spacy():
    if spacy is None:
        return None
    try:
        return spacy.load("en_core_web_sm")
    except Exception:
        return None


def _extract_entities(text: str) -> List[Dict[str, Any]]:
    nlp = _load_spacy()
    if not nlp or not text:
        return []
    doc = nlp(text[:20000])
    return [{"text": ent.text, "label": ent.label_} for ent in doc.ents[:200]]


def _entity_counts(ents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not ents:
        return []
    df = pd.DataFrame(ents)
    if df.empty or "label" not in df.columns:
        return []
    counts = df["label"].value_counts().reset_index()
    counts.columns = ["label", "count"]
    return counts.to_dict(orient="records")


def _caption_image(path: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {"caption": "", "warnings": [], "model": OLLAMA_VISION_MODEL}
    if Image is None:
        out["warnings"].append("Pillow not installed; captioning skipped.")
        return out
    try:
        with open(path, "rb") as f:
            img_bytes = f.read()
        b64 = base64.b64encode(img_bytes).decode("utf-8")
        payload = {
            "model": OLLAMA_VISION_MODEL,
            "prompt": OLLAMA_VISION_PROMPT,
            "images": [b64],
            "stream": False,
        }
        resp = requests.post(
            f"{OLLAMA_VISION_BASE_URL}/api/generate",
            json=payload,
            timeout=OLLAMA_VISION_TIMEOUT,
        )
        if resp.status_code != 200:
            out["warnings"].append(f"Ollama vision failed: {resp.status_code} {resp.text}")
            return out
        data = resp.json()
        out["caption"] = data.get("response", "").strip()
    except Exception as exc:
        out["warnings"].append(f"Ollama vision failed: {exc}")
    return out


def _extract_text_unstructured(path: str) -> str:
    if partition is None:
        return convert_to_markdown(path)
    elements = partition(filename=path)
    return "\n".join([str(el) for el in elements if str(el).strip()])


def _extract_text_image(path: str) -> str:
    if SKIP_OCR or pytesseract is None or Image is None:
        return ""
    img = Image.open(path)
    return pytesseract.image_to_string(img)


def _extract_text_video(path: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {"text": "", "duration": None, "warnings": [], "caption": ""}
    if ffmpeg is None:
        out["warnings"].append("ffmpeg-python not installed; video analysis skipped.")
        return out

    try:
        info = ffmpeg.probe(path)
        if "format" in info and "duration" in info["format"]:
            out["duration"] = float(info["format"]["duration"])
    except Exception:
        pass

    if SKIP_OCR or pytesseract is None or Image is None:
        if SKIP_OCR:
            out["warnings"].append("OCR disabled by UNSTRUCTURED_SKIP_OCR.")
        else:
            out["warnings"].append("pytesseract not installed; frame OCR skipped.")

    try:
        with tempfile.TemporaryDirectory() as tmpd:
            frame_path = os.path.join(tmpd, "frame.jpg")
            (
                ffmpeg
                .input(path, ss=0)
                .output(frame_path, vframes=1)
                .overwrite_output()
                .run(quiet=True)
            )
            out["text"] = _extract_text_image(frame_path)
            caption_out = _caption_image(frame_path)
            out["caption"] = caption_out.get("caption", "")
            out["warnings"].extend(caption_out.get("warnings", []))
    except Exception as exc:
        out["warnings"].append(f"frame extraction failed: {exc}")
    return out


def analyze_unstructured(filename: str, payload: bytes) -> Dict[str, Any]:
    ext = Path(filename).suffix.lower()
    temp_path = save_temp_upload(filename, payload)

    result: Dict[str, Any] = {"file_name": filename, "file_type": ext, "warnings": []}

    text = ""
    caption_out: Dict[str, Any] | None = None
    video_out: Dict[str, Any] | None = None

    if ext in DOC_EXTS:
        if partition is None:
            result["warnings"].append("unstructured not installed; using markdown fallback.")
        text = _extract_text_unstructured(temp_path)
    elif ext in IMAGE_EXTS:
        if SKIP_OCR:
            result["warnings"].append("OCR disabled by UNSTRUCTURED_SKIP_OCR.")
        elif pytesseract is None or Image is None:
            result["warnings"].append("pytesseract not installed; image OCR skipped.")
        text = _extract_text_image(temp_path)
        caption_out = _caption_image(temp_path)
    elif ext in VIDEO_EXTS:
        video_out = _extract_text_video(temp_path)
        text = video_out.get("text", "")
        if video_out.get("duration") is not None:
            result["duration"] = video_out.get("duration")
    else:
        text = convert_to_markdown(temp_path)

    if caption_out:
        if caption_out.get("caption"):
            result["caption"] = caption_out.get("caption")
            result["caption_model"] = caption_out.get("model") or OLLAMA_VISION_MODEL
        result["warnings"].extend(caption_out.get("warnings", []))

    if video_out:
        if video_out.get("caption"):
            result["caption"] = video_out.get("caption")
            result["caption_model"] = video_out.get("model") or OLLAMA_VISION_MODEL
        result["warnings"].extend(video_out.get("warnings", []))

    ents = _extract_entities(text)
    result.update(
        {
            "text_preview": text[:4000],
            "entities": ents,
            "entity_counts": _entity_counts(ents),
            "text_length": len(text),
        }
    )
    return result
