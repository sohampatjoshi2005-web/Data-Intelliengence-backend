from __future__ import annotations

import base64
import io
from typing import Any, Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


def _fig_to_base64(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=120, bbox_inches="tight")
    buf.seek(0)
    data = base64.b64encode(buf.read()).decode("utf-8")
    plt.close(fig)
    return data


def generate_visual_pack(df: pd.DataFrame) -> List[Dict[str, Any]]:
    visuals: List[Dict[str, Any]] = []
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    if num_cols:
        col = num_cols[0]
        fig, ax = plt.subplots(figsize=(7, 4))
        sns.histplot(df[col].dropna(), kde=True, ax=ax)
        ax.set_title(f"Distribution + KDE: {col}")
        visuals.append({"title": f"Distribution of {col}", "image_base64": _fig_to_base64(fig)})

    if len(num_cols) >= 2:
        fig, ax = plt.subplots(figsize=(7, 4))
        sns.scatterplot(data=df, x=num_cols[0], y=num_cols[1], ax=ax)
        ax.set_title(f"Scatter: {num_cols[0]} vs {num_cols[1]}")
        visuals.append({"title": "Scatter Impact", "image_base64": _fig_to_base64(fig)})

        corr = df[num_cols].corr(numeric_only=True)
        fig, ax = plt.subplots(figsize=(7, 5))
        sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax)
        ax.set_title("Correlation Heatmap")
        visuals.append({"title": "Correlation Heatmap", "image_base64": _fig_to_base64(fig)})

    if cat_cols and num_cols:
        fig, ax = plt.subplots(figsize=(8, 4))
        ccol = cat_cols[0]
        ncol = num_cols[0]
        sns.boxplot(data=df, x=ccol, y=ncol, ax=ax)
        ax.set_title(f"Boxplot: {ncol} by {ccol}")
        ax.tick_params(axis="x", rotation=25)
        visuals.append({"title": "Category Variance", "image_base64": _fig_to_base64(fig)})

        fig, ax = plt.subplots(figsize=(6, 6))
        counts = df[ccol].value_counts().head(8)
        ax.pie(counts.values, labels=counts.index, autopct="%1.1f%%")
        ax.set_title(f"Category Split: {ccol}")
        visuals.append({"title": "Category Ratio", "image_base64": _fig_to_base64(fig)})

    # Date trend if any datetime-like column exists.
    dt_col = None
    for c in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            dt_col = c
            break
        if df[c].dtype == object:
            converted = pd.to_datetime(df[c], errors="coerce")
            if converted.notna().sum() > max(10, int(0.5 * len(df))):
                df[c] = converted
                dt_col = c
                break

    if dt_col is not None:
        trend = df.dropna(subset=[dt_col]).copy()
        if not trend.empty:
            trend["__date"] = trend[dt_col].dt.date
            series = trend.groupby("__date").size().reset_index(name="count")
            fig, ax = plt.subplots(figsize=(8, 4))
            sns.lineplot(data=series, x="__date", y="count", ax=ax)
            ax.set_title(f"Time Trend by {dt_col}")
            ax.tick_params(axis="x", rotation=25)
            visuals.append({"title": "Time Trend", "image_base64": _fig_to_base64(fig)})

    return visuals
