from __future__ import annotations

import base64
import io
import json
import os
from pathlib import Path
from typing import Tuple

import pandas as pd
import requests

from app.core.config import settings

try:
    from markitdown import MarkItDown
except Exception:
    MarkItDown = None

try:
    import pytesseract
    from PIL import Image
except Exception:
    pytesseract = None
    Image = None

try:
    import pdfplumber
except Exception:
    pdfplumber = None

try:
    import yaml
except Exception:
    yaml = None

try:
    from docx import Document
except Exception:
    Document = None

try:
    import xmltodict
except Exception:
    xmltodict = None

try:
    from markdown import markdown as md_to_html
except Exception:
    md_to_html = None

try:
    from markdownify import markdownify as html_to_md
except Exception:
    html_to_md = None

try:
    import boto3
except Exception:
    boto3 = None


def _encode_bytes(data: bytes) -> str:
    return base64.b64encode(data).decode("utf-8")


def run_transformation(file_name: str, payload: bytes, transform_type: str) -> Tuple[str, str, str]:
    name = Path(file_name).stem
    ext = Path(file_name).suffix.lower()

    def _img_media_type() -> str:
        if ext in {".jpg", ".jpeg"}:
            return "image/jpeg"
        if ext == ".png":
            return "image/png"
        return "image/png"

    def _prep_image_for_vision(raw: bytes) -> bytes:
        if Image is None:
            return raw
        try:
            img = Image.open(io.BytesIO(raw)).convert("RGB")
            max_side = 1024
            w, h = img.size
            scale = min(max_side / max(w, h), 1.0)
            if scale < 1.0:
                img = img.resize((int(w * scale), int(h * scale)))
            out = io.BytesIO()
            img.save(out, format="PNG")
            return out.getvalue()
        except Exception:
            return raw

    if transform_type == "CSV → Markdown Table":
        df = pd.read_csv(io.BytesIO(payload))
        out = df.to_markdown(index=False).encode("utf-8")
        return f"{name}.md", "text/markdown", _encode_bytes(out)

    if transform_type == "CSV → HTML Table":
        df = pd.read_csv(io.BytesIO(payload))
        out = df.to_html(index=False).encode("utf-8")
        return f"{name}.html", "text/html", _encode_bytes(out)

    if transform_type == "CSV → Excel (XLSX)":
        df = pd.read_csv(io.BytesIO(payload))
        out = io.BytesIO()
        with pd.ExcelWriter(out, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)
        return f"{name}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _encode_bytes(out.getvalue())

    if transform_type == "CSV → JSON":
        df = pd.read_csv(io.BytesIO(payload))
        out = df.to_json(orient="records").encode("utf-8")
        return f"{name}.json", "application/json", _encode_bytes(out)

    if transform_type == "CSV → TSV":
        df = pd.read_csv(io.BytesIO(payload))
        out = io.StringIO()
        df.to_csv(out, index=False, sep="\t")
        return f"{name}.tsv", "text/tab-separated-values", _encode_bytes(out.getvalue().encode("utf-8"))

    if transform_type == "TSV → JSON":
        df = pd.read_csv(io.BytesIO(payload), sep="\t")
        out = df.to_json(orient="records").encode("utf-8")
        return f"{name}.json", "application/json", _encode_bytes(out)

    if transform_type == "TSV → Excel (XLSX)":
        df = pd.read_csv(io.BytesIO(payload), sep="\t")
        out = io.BytesIO()
        with pd.ExcelWriter(out, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)
        return f"{name}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _encode_bytes(out.getvalue())

    if transform_type == "TSV → Markdown Table":
        df = pd.read_csv(io.BytesIO(payload), sep="\t")
        out = df.to_markdown(index=False).encode("utf-8")
        return f"{name}.md", "text/markdown", _encode_bytes(out)

    if transform_type == "TSV → CSV":
        df = pd.read_csv(io.BytesIO(payload), sep="\t")
        out = io.StringIO()
        df.to_csv(out, index=False)
        return f"{name}.csv", "text/csv", _encode_bytes(out.getvalue().encode("utf-8"))

    if transform_type == "Excel → TSV":
        df = pd.read_excel(io.BytesIO(payload))
        out = io.StringIO()
        df.to_csv(out, index=False, sep="\t")
        return f"{name}.tsv", "text/tab-separated-values", _encode_bytes(out.getvalue().encode("utf-8"))

    if transform_type == "Excel → Markdown Table":
        df = pd.read_excel(io.BytesIO(payload))
        out = df.to_markdown(index=False).encode("utf-8")
        return f"{name}.md", "text/markdown", _encode_bytes(out)

    if transform_type == "Excel → CSV":
        df = pd.read_excel(io.BytesIO(payload))
        out = io.StringIO()
        df.to_csv(out, index=False)
        return f"{name}.csv", "text/csv", _encode_bytes(out.getvalue().encode("utf-8"))

    if transform_type == "Excel → JSON":
        df = pd.read_excel(io.BytesIO(payload))
        out = df.to_json(orient="records").encode("utf-8")
        return f"{name}.json", "application/json", _encode_bytes(out)

    if transform_type == "JSON → TSV":
        df = pd.read_json(io.BytesIO(payload))
        out = io.StringIO()
        df.to_csv(out, index=False, sep="\t")
        return f"{name}.tsv", "text/tab-separated-values", _encode_bytes(out.getvalue().encode("utf-8"))

    if transform_type == "JSON → Markdown Table":
        df = pd.read_json(io.BytesIO(payload))
        out = df.to_markdown(index=False).encode("utf-8")
        return f"{name}.md", "text/markdown", _encode_bytes(out)

    if transform_type == "JSON → YAML":
        if yaml is None:
            raise RuntimeError("pyyaml is not installed.")
        data = json.loads(payload.decode("utf-8"))
        out = yaml.safe_dump(data, sort_keys=False).encode("utf-8")
        return f"{name}.yaml", "text/yaml", _encode_bytes(out)

    if transform_type == "YAML → JSON":
        if yaml is None:
            raise RuntimeError("pyyaml is not installed.")
        data = yaml.safe_load(payload.decode("utf-8"))
        out = json.dumps(data, indent=2).encode("utf-8")
        return f"{name}.json", "application/json", _encode_bytes(out)

    if transform_type == "XML → JSON":
        if xmltodict is None:
            raise RuntimeError("xmltodict is not installed.")
        data = xmltodict.parse(payload.decode("utf-8"))
        out = json.dumps(data, indent=2).encode("utf-8")
        return f"{name}.json", "application/json", _encode_bytes(out)

    if transform_type == "JSON → XML":
        if xmltodict is None:
            raise RuntimeError("xmltodict is not installed.")
        data = json.loads(payload.decode("utf-8"))
        out = xmltodict.unparse(data, pretty=True).encode("utf-8")
        return f"{name}.xml", "application/xml", _encode_bytes(out)

    if transform_type == "JSON → Pretty":
        data = json.loads(payload.decode("utf-8"))
        out = json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8")
        return f"{name}.json", "application/json", _encode_bytes(out)

    if transform_type == "JSON → Minify":
        data = json.loads(payload.decode("utf-8"))
        out = json.dumps(data, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return f"{name}.json", "application/json", _encode_bytes(out)

    if transform_type == "JSON → CSV":
        df = pd.read_json(io.BytesIO(payload))
        out = io.StringIO()
        df.to_csv(out, index=False)
        return f"{name}.csv", "text/csv", _encode_bytes(out.getvalue().encode("utf-8"))

    if transform_type == "JSON → Excel (XLSX)":
        df = pd.read_json(io.BytesIO(payload))
        out = io.BytesIO()
        with pd.ExcelWriter(out, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)
        return f"{name}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _encode_bytes(out.getvalue())

    if transform_type == "TXT → Markdown":
        txt = payload.decode("utf-8", errors="ignore")
        out = f"```\n{txt}\n```\n".encode("utf-8")
        return f"{name}.md", "text/markdown", _encode_bytes(out)

    if transform_type == "TXT → HTML":
        txt = payload.decode("utf-8", errors="ignore")
        out = f"<pre>{txt}</pre>".encode("utf-8")
        return f"{name}.html", "text/html", _encode_bytes(out)

    if transform_type == "PDF/DOCX → Markdown":
        if MarkItDown is None:
            raise RuntimeError("markitdown is not installed.")
        tmp_path = f"/tmp/{file_name}"
        with open(tmp_path, "wb") as f:
            f.write(payload)
        md = MarkItDown().convert(tmp_path).text_content
        return f"{name}.md", "text/markdown", _encode_bytes(md.encode("utf-8"))

    if transform_type == "PDF → Text":
        if pdfplumber is None:
            raise RuntimeError("pdfplumber is not installed.")
        tmp_path = f"/tmp/{file_name}"
        with open(tmp_path, "wb") as f:
            f.write(payload)
        chunks = []
        with pdfplumber.open(tmp_path) as pdf:
            for page in pdf.pages:
                chunks.append(page.extract_text() or "")
        out = "\n\n".join(chunks).encode("utf-8")
        return f"{name}.txt", "text/plain", _encode_bytes(out)

    if transform_type == "DOCX → Text":
        if Document is None:
            raise RuntimeError("python-docx is not installed.")
        tmp_path = f"/tmp/{file_name}"
        with open(tmp_path, "wb") as f:
            f.write(payload)
        doc = Document(tmp_path)
        out = "\n".join([p.text for p in doc.paragraphs]).encode("utf-8")
        return f"{name}.txt", "text/plain", _encode_bytes(out)

    if transform_type == "Markdown → HTML":
        if md_to_html is None:
            raise RuntimeError("markdown is not installed.")
        txt = payload.decode("utf-8", errors="ignore")
        out = md_to_html(txt).encode("utf-8")
        return f"{name}.html", "text/html", _encode_bytes(out)

    if transform_type == "HTML → Markdown":
        if html_to_md is None:
            raise RuntimeError("markdownify is not installed.")
        txt = payload.decode("utf-8", errors="ignore")
        out = html_to_md(txt).encode("utf-8")
        return f"{name}.md", "text/markdown", _encode_bytes(out)

    if transform_type in ("Image → Text (OCR)", "Image → Text (Vision)"):
        provider = os.getenv("TRANSFORM_IMAGE_PROVIDER", "moondream").lower()
        if provider == "bedrock" and boto3 is not None:
            region = os.getenv("BEDROCK_REGION", "us-east-2")
            model_id = os.getenv("BEDROCK_VISION_MODEL_ID", os.getenv("BEDROCK_MODEL_ID", ""))
            if not model_id:
                raise RuntimeError("BEDROCK_VISION_MODEL_ID or BEDROCK_MODEL_ID is required for Bedrock image OCR.")
            client = boto3.client("bedrock-runtime", region_name=region)
            img_b64 = base64.b64encode(payload).decode("utf-8")
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 256,
                "temperature": 0.0,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "image", "source": {"type": "base64", "media_type": _img_media_type(), "data": img_b64}},
                            {"type": "text", "text": "Describe the image in plain text. If there is readable text, include it."},
                        ],
                    }
                ],
            }
            resp = client.invoke_model(
                modelId=model_id,
                body=json.dumps(body).encode("utf-8"),
                contentType="application/json",
                accept="application/json",
            )
            raw = resp["body"].read().decode("utf-8")
            text = json.loads(raw)["content"][0]["text"]
            return f"{name}.txt", "text/plain", _encode_bytes(text.encode("utf-8"))

        if provider in ("moondream", "ollama"):
            base_url = settings.ollama_vision_base_url.rstrip("/")
            model = os.getenv("OLLAMA_VISION_MODEL", "moondream")
            timeout = int(os.getenv("OLLAMA_VISION_TIMEOUT", "300"))
            prepared = _prep_image_for_vision(payload)
            img_b64 = base64.b64encode(prepared).decode("utf-8")
            prompt = "Describe the image in plain text. If there is readable text, include it."
            payload_json = {
                "model": model,
                "prompt": prompt,
                "images": [img_b64],
                "stream": False,
                "options": {"num_predict": 256},
            }
            resp = requests.post(f"{base_url}/api/generate", json=payload_json, timeout=timeout)
            if resp.status_code != 200:
                raise RuntimeError(f"Ollama vision failed: {resp.status_code} {resp.text}")
            data = resp.json()
            text = data.get("response", "").strip()
            if not text:
                raise RuntimeError("Ollama vision returned empty text.")
            return f"{name}.txt", "text/plain", _encode_bytes(text.encode("utf-8"))

        if provider == "ocr":
            if pytesseract is None or Image is None:
                raise RuntimeError("pytesseract/Pillow is not installed.")
            tmp_path = f"/tmp/{file_name}"
            with open(tmp_path, "wb") as f:
                f.write(payload)
            img = Image.open(tmp_path)
            text = pytesseract.image_to_string(img)
            return f"{name}.txt", "text/plain", _encode_bytes(text.encode("utf-8"))

        raise RuntimeError(f"Unsupported TRANSFORM_IMAGE_PROVIDER: {provider}")

    if transform_type == "Image → Markdown (Caption)":
        provider = os.getenv("TRANSFORM_IMAGE_PROVIDER", "moondream").lower()
        if provider == "bedrock" and boto3 is not None:
            region = os.getenv("BEDROCK_REGION", "us-east-2")
            model_id = os.getenv("BEDROCK_VISION_MODEL_ID", os.getenv("BEDROCK_MODEL_ID", ""))
            if not model_id:
                raise RuntimeError("BEDROCK_VISION_MODEL_ID or BEDROCK_MODEL_ID is required for Bedrock caption.")
            client = boto3.client("bedrock-runtime", region_name=region)
            img_b64 = base64.b64encode(payload).decode("utf-8")
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 128,
                "temperature": 0.2,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "image", "source": {"type": "base64", "media_type": _img_media_type(), "data": img_b64}},
                            {"type": "text", "text": "Write a concise one-sentence caption for this image."},
                        ],
                    }
                ],
            }
            resp = client.invoke_model(
                modelId=model_id,
                body=json.dumps(body).encode("utf-8"),
                contentType="application/json",
                accept="application/json",
            )
            raw = resp["body"].read().decode("utf-8")
            caption = json.loads(raw)["content"][0]["text"]
            md = f"![caption]({file_name})\n\n{caption}\n"
            return f"{name}.md", "text/markdown", _encode_bytes(md.encode("utf-8"))

        if provider in ("moondream", "ollama"):
            base_url = settings.ollama_vision_base_url.rstrip("/")
            model = os.getenv("OLLAMA_VISION_MODEL", "moondream")
            timeout = int(os.getenv("OLLAMA_VISION_TIMEOUT", "300"))
            prepared = _prep_image_for_vision(payload)
            img_b64 = base64.b64encode(prepared).decode("utf-8")
            prompt = "Write a concise one-sentence caption for this image."
            payload_json = {
                "model": model,
                "prompt": prompt,
                "images": [img_b64],
                "stream": False,
                "options": {"num_predict": 128},
            }
            resp = requests.post(f"{base_url}/api/generate", json=payload_json, timeout=timeout)
            if resp.status_code != 200:
                raise RuntimeError(f"Ollama vision failed: {resp.status_code} {resp.text}")
            data = resp.json()
            caption = data.get("response", "").strip()
            if not caption:
                raise RuntimeError("Ollama vision returned empty caption.")
            md = f"![caption]({file_name})\n\n{caption}\n"
            return f"{name}.md", "text/markdown", _encode_bytes(md.encode("utf-8"))

        if provider == "ocr":
            if pytesseract is None or Image is None:
                raise RuntimeError("pytesseract/Pillow is not installed.")
            tmp_path = f"/tmp/{file_name}"
            with open(tmp_path, "wb") as f:
                f.write(payload)
            img = Image.open(tmp_path)
            text = pytesseract.image_to_string(img)
            md = f"![image]({file_name})\n\n{text.strip()}\n"
            return f"{name}.md", "text/markdown", _encode_bytes(md.encode("utf-8"))

        raise RuntimeError(f"Unsupported TRANSFORM_IMAGE_PROVIDER: {provider}")

    raise ValueError(f"Unknown transform_type: {transform_type}")
