from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

try:
    import mlflow
except Exception:
    mlflow = None


def _safe_name(name: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in name)[:120]


class ExperimentTracker:
    """MLflow-first tracker with local JSONL fallback."""

    def __init__(self) -> None:
        self.tracking_uri = os.getenv("MLFLOW_TRACKING_URI", "").strip()
        self.experiment_name = os.getenv("MLFLOW_EXPERIMENT_NAME", "agentic_automl")
        self.local_dir = Path(os.getenv("LOCAL_EXPERIMENT_DIR", "artifacts/experiments"))
        self.local_dir.mkdir(parents=True, exist_ok=True)

    def _flatten_metrics(self, metrics: Dict[str, Any], prefix: str = "") -> Dict[str, float]:
        out: Dict[str, float] = {}
        for k, v in (metrics or {}).items():
            key = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
            if isinstance(v, dict):
                out.update(self._flatten_metrics(v, key))
            elif isinstance(v, (int, float)):
                out[key] = float(v)
        return out

    def _flatten_params(self, params: Dict[str, Any], prefix: str = "") -> Dict[str, str]:
        out: Dict[str, str] = {}
        for k, v in (params or {}).items():
            key = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
            if isinstance(v, dict):
                out.update(self._flatten_params(v, key))
            else:
                out[key] = str(v)
        return out

    def log_run(
        self,
        *,
        run_name: str,
        dataset_name: str,
        business_problem: str,
        problem_type: str,
        params: Dict[str, Any],
        metrics: Dict[str, Any],
        artifacts: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "run_name": run_name,
            "dataset_name": dataset_name,
            "business_problem": business_problem,
            "problem_type": problem_type,
            "params": params,
            "metrics": metrics,
            "artifacts": artifacts or {},
        }

        if mlflow is not None and self.tracking_uri:
            try:
                mlflow.set_tracking_uri(self.tracking_uri)
                mlflow.set_experiment(self.experiment_name)
                with mlflow.start_run(run_name=_safe_name(run_name)) as run:
                    for k, v in self._flatten_params(params).items():
                        mlflow.log_param(k, v)
                    for k, v in self._flatten_metrics(metrics).items():
                        mlflow.log_metric(k, v)
                    for k, v in (artifacts or {}).items():
                        mlflow.set_tag(f"artifact.{k}", str(v))
                    mlflow.set_tag("dataset_name", dataset_name)
                    mlflow.set_tag("problem_type", problem_type)
                    return {
                        "backend": "mlflow",
                        "tracking_uri": self.tracking_uri,
                        "experiment_name": self.experiment_name,
                        "run_id": run.info.run_id,
                    }
            except Exception as exc:
                payload["mlflow_error"] = str(exc)

        log_path = self.local_dir / "runs.jsonl"
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=True) + "\n")
        return {
            "backend": "local_jsonl",
            "log_path": str(log_path),
            "run_name": run_name,
        }
