from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional

import pandas as pd


DEFAULT_PREPROCESS_CONFIG: Dict[str, Any] = {
    "drop_columns": [],
    "drop_duplicates": True,
    "missing_strategy": "auto",
    "missing_constant": "0",
    "cap_outliers": True,
    "outlier_iqr_k": 1.5,
    "remove_low_variance": True,
    "low_variance_threshold": 0.0,
    "parse_dates": [],
    "date_feature_parts": True,
    "auto_detect_dates": True,
}


def get_default_preprocess_config() -> Dict[str, Any]:
    return dict(DEFAULT_PREPROCESS_CONFIG)


def _safe_list(value: Any) -> List[str]:
    if not value:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v) for v in value if str(v).strip()]
    return [str(value)]


def _is_numeric(series: pd.Series) -> bool:
    return pd.api.types.is_numeric_dtype(series)


def apply_preprocessing(
    df: pd.DataFrame,
    *,
    target_column: Optional[str],
    config: Optional[Dict[str, Any]],
) -> pd.DataFrame:
    if not config:
        config = get_default_preprocess_config()

    out = df.copy()
    target = str(target_column) if target_column else None

    drop_columns = _safe_list(config.get("drop_columns"))
    if target and target in drop_columns:
        raise ValueError("preprocess_config.drop_columns cannot include target column")
    if drop_columns:
        out = out.drop(columns=[c for c in drop_columns if c in out.columns], errors="ignore")

    if bool(config.get("drop_duplicates")):
        out = out.drop_duplicates()

    parse_dates = _safe_list(config.get("parse_dates"))
    if not parse_dates and bool(config.get("auto_detect_dates")):
        candidate_cols = [c for c in out.columns if out[c].dtype == "object"]
        for col in candidate_cols:
            parsed = pd.to_datetime(out[col], errors="coerce")
            if parsed.notna().mean() >= 0.8:
                parse_dates.append(col)
    if parse_dates:
        for col in parse_dates:
            if col in out.columns:
                out[col] = pd.to_datetime(out[col], errors="coerce")
        if bool(config.get("date_feature_parts")):
            for col in parse_dates:
                if col in out.columns and pd.api.types.is_datetime64_any_dtype(out[col]):
                    out[f"{col}_year"] = out[col].dt.year
                    out[f"{col}_month"] = out[col].dt.month
                    out[f"{col}_day"] = out[col].dt.day
                    out[f"{col}_dayofweek"] = out[col].dt.dayofweek

    missing_strategy = str(config.get("missing_strategy", "auto")).lower()
    missing_constant = config.get("missing_constant", "")
    if missing_strategy in {"auto", "mean", "median", "mode", "constant"}:
        for col in out.columns:
            s = out[col]
            if s.isna().any():
                if missing_strategy == "auto":
                    if _is_numeric(s):
                        out[col] = s.fillna(s.mean())
                    else:
                        mode = s.mode(dropna=True)
                        out[col] = s.fillna(mode.iloc[0] if not mode.empty else "")
                elif missing_strategy == "mean":
                    if _is_numeric(s):
                        out[col] = s.fillna(s.mean())
                elif missing_strategy == "median":
                    if _is_numeric(s):
                        out[col] = s.fillna(s.median())
                elif missing_strategy == "mode":
                    mode = s.mode(dropna=True)
                    out[col] = s.fillna(mode.iloc[0] if not mode.empty else "")
                elif missing_strategy == "constant":
                    out[col] = s.fillna(missing_constant)

    if bool(config.get("cap_outliers")):
        iqr_k = float(config.get("outlier_iqr_k", 1.5))
        for col in out.columns:
            s = out[col]
            if _is_numeric(s):
                q1 = s.quantile(0.25)
                q3 = s.quantile(0.75)
                iqr = q3 - q1
                if pd.notna(iqr) and iqr > 0:
                    lower = q1 - iqr_k * iqr
                    upper = q3 + iqr_k * iqr
                    out[col] = s.clip(lower=lower, upper=upper)

    if bool(config.get("remove_low_variance")):
        threshold = float(config.get("low_variance_threshold", 0.0))
        drop_lv: List[str] = []
        for col in out.columns:
            s = out[col]
            if _is_numeric(s):
                if float(s.var(ddof=0)) <= threshold:
                    drop_lv.append(col)
        if target and target in drop_lv:
            drop_lv.remove(target)
        if drop_lv:
            out = out.drop(columns=drop_lv, errors="ignore")

    return out
