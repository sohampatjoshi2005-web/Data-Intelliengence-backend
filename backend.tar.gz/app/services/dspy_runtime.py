from __future__ import annotations

import json
import threading
from typing import Any, Optional

from app.core.config import settings

_lock = threading.Lock()
_configured = False


def _normalize_ollama_base(url: str) -> str:
    base = (url or "").strip()
    if base.endswith("/v1"):
        base = base[:-3]
    return base or "http://localhost:11434"


def _configure_dspy() -> Optional["dspy"]:
    global _configured
    try:
        import dspy  # type: ignore
    except Exception:
        return None

    with _lock:
        if _configured:
            return dspy
        if not settings.dspy_enabled:
            return None

        api_base = _normalize_ollama_base(settings.ollama_base_url)
        model = settings.dspy_model or settings.ollama_model
        lm = dspy.LM(
            f"ollama_chat/{model}",
            api_base=api_base,
            api_key=settings.ollama_api_key or "ollama",
        )
        dspy.configure(lm=lm)
        _configured = True
        return dspy


def dspy_ready() -> bool:
    return _configure_dspy() is not None


def dspy_kb_answer(question: str, context: str) -> str:
    dspy = _configure_dspy()
    if dspy is None:
        return ""

    class KBAnswer(dspy.Signature):
        """Answer using only the provided context."""

        context: str = dspy.InputField()
        question: str = dspy.InputField()
        answer: str = dspy.OutputField()

    module = dspy.ChainOfThought(KBAnswer)
    result = module(context=context, question=question)
    return str(getattr(result, "answer", "") or "").strip()


def dspy_kg_answer(question: str, neighbors: list[dict[str, Any]]) -> str:
    dspy = _configure_dspy()
    if dspy is None:
        return ""

    class KGAnswer(dspy.Signature):
        """Answer using only the graph neighbors provided."""

        neighbors: str = dspy.InputField()
        question: str = dspy.InputField()
        answer: str = dspy.OutputField()

    module = dspy.ChainOfThought(KGAnswer)
    neighbors_txt = json.dumps(neighbors, ensure_ascii=False)
    result = module(neighbors=neighbors_txt, question=question)
    return str(getattr(result, "answer", "") or "").strip()


def dspy_nl_to_sql(question: str, columns: list[str], table_name: str = "data") -> str:
    dspy = _configure_dspy()
    if dspy is None:
        return ""

    class NL2SQL(dspy.Signature):
        """Write a single SQL query for the given table and columns."""

        question: str = dspy.InputField()
        schema: str = dspy.InputField()
        sql: str = dspy.OutputField()

    module = dspy.Predict(NL2SQL)
    schema = f"Table: {table_name}. Columns: {', '.join(columns)}. Use DuckDB SQL."
    result = module(question=question, schema=schema)
    sql = str(getattr(result, "sql", "") or "").strip()
    return sql


def dspy_insights(query: str, execution: dict[str, Any]) -> str:
    dspy = _configure_dspy()
    if dspy is None:
        return ""

    class Insights(dspy.Signature):
        """Summarize insights from executed analytics results."""

        query: str = dspy.InputField()
        execution: str = dspy.InputField()
        insights: str = dspy.OutputField()

    module = dspy.Predict(Insights)
    payload = json.dumps(execution, ensure_ascii=False)
    result = module(query=query, execution=payload)
    return str(getattr(result, "insights", "") or "").strip()
