from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd


class LocalFeatureStore:
    """Minimal online/offline feature store facade.

    Offline: parquet files by entity/table.
    Online: latest features per key from parquet snapshot.
    """

    def __init__(self) -> None:
        self.root = Path(os.getenv("FEATURE_STORE_DIR", "artifacts/feature_store"))
        self.offline_dir = self.root / "offline"
        self.online_dir = self.root / "online"
        self.offline_dir.mkdir(parents=True, exist_ok=True)
        self.online_dir.mkdir(parents=True, exist_ok=True)

    def _offline_path(self, table: str) -> Path:
        safe = "".join(ch if ch.isalnum() or ch in {"_", "-"} else "_" for ch in table)
        return self.offline_dir / f"{safe}.parquet"

    def _online_path(self, table: str) -> Path:
        safe = "".join(ch if ch.isalnum() or ch in {"_", "-"} else "_" for ch in table)
        return self.online_dir / f"{safe}.parquet"

    def upsert_offline(self, table: str, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        df_new = pd.DataFrame(rows)
        path = self._offline_path(table)
        if path.exists():
            try:
                old = pd.read_parquet(path)
                df = pd.concat([old, df_new], ignore_index=True)
            except Exception:
                df = df_new.copy()
        else:
            df = df_new.copy()
        df.to_parquet(path, index=False)
        return {"ok": True, "table": table, "rows": int(len(df_new)), "offline_path": str(path)}

    def materialize_online(self, table: str, key_col: str, ts_col: str | None = None) -> Dict[str, Any]:
        path = self._offline_path(table)
        if not path.exists():
            return {"ok": False, "error": "offline_table_missing"}
        df = pd.read_parquet(path)
        if key_col not in df.columns:
            return {"ok": False, "error": f"missing_key_col:{key_col}"}

        if ts_col and ts_col in df.columns:
            df = df.sort_values(ts_col)
        latest = df.drop_duplicates(subset=[key_col], keep="last")

        opath = self._online_path(table)
        latest.to_parquet(opath, index=False)
        return {"ok": True, "table": table, "rows": int(len(latest)), "online_path": str(opath)}

    def read_online(self, table: str, key_col: str, key_val: Any) -> Dict[str, Any]:
        path = self._online_path(table)
        if not path.exists():
            return {"ok": False, "error": "online_table_missing"}
        df = pd.read_parquet(path)
        if key_col not in df.columns:
            return {"ok": False, "error": f"missing_key_col:{key_col}"}
        out = df[df[key_col].astype(str) == str(key_val)]
        return {"ok": True, "table": table, "record": out.head(1).to_dict(orient="records")[0] if not out.empty else None}

    def list_tables(self) -> Dict[str, Any]:
        offline = sorted([p.stem for p in self.offline_dir.glob("*.parquet")])
        online = sorted([p.stem for p in self.online_dir.glob("*.parquet")])
        return {"offline_tables": offline, "online_tables": online}
