from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


class LocalModelRegistry:
    def __init__(self) -> None:
        root = Path(os.getenv("MODEL_REGISTRY_DIR", "artifacts/registry"))
        root.mkdir(parents=True, exist_ok=True)
        self.path = root / "models.json"
        if not self.path.exists():
            self.path.write_text(json.dumps({"models": []}, indent=2), encoding="utf-8")

    def _load(self) -> Dict[str, Any]:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"models": []}

    def _save(self, payload: Dict[str, Any]) -> None:
        self.path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def register(self, model_record: Dict[str, Any]) -> Dict[str, Any]:
        data = self._load()
        models: List[Dict[str, Any]] = data.get("models", [])
        model_id = str(model_record.get("model_id") or "")
        now = datetime.now(timezone.utc).isoformat()

        found = False
        for m in models:
            if str(m.get("model_id")) == model_id:
                m.update(model_record)
                m["updated_at"] = now
                found = True
                break
        if not found:
            rec = dict(model_record)
            rec.setdefault("stage", "none")
            rec.setdefault("approvals", [])
            rec.setdefault("status", "active")
            rec["created_at"] = now
            rec["updated_at"] = now
            models.append(rec)

        data["models"] = models
        self._save(data)
        return {"ok": True, "model_id": model_id, "registry_path": str(self.path)}

    def list_models(self) -> List[Dict[str, Any]]:
        return self._load().get("models", [])

    def get_model(self, model_id: str) -> Optional[Dict[str, Any]]:
        for m in self.list_models():
            if str(m.get("model_id")) == str(model_id):
                return m
        return None

    def approve(self, model_id: str, approver: str, note: str = "") -> Dict[str, Any]:
        data = self._load()
        now = datetime.now(timezone.utc).isoformat()
        for m in data.get("models", []):
            if str(m.get("model_id")) == str(model_id):
                approvals = m.setdefault("approvals", [])
                approvals.append({"approver": approver, "note": note, "at": now})
                m["updated_at"] = now
                self._save(data)
                return {"ok": True, "model_id": model_id, "approvals": approvals}
        return {"ok": False, "error": "model_not_found"}

    def promote(self, model_id: str, stage: str, actor: str) -> Dict[str, Any]:
        if stage not in {"staging", "production", "archived"}:
            return {"ok": False, "error": "invalid_stage"}

        data = self._load()
        now = datetime.now(timezone.utc).isoformat()

        # keep one production model active
        if stage == "production":
            for m in data.get("models", []):
                if m.get("stage") == "production" and str(m.get("model_id")) != str(model_id):
                    m["stage"] = "staging"
                    m["updated_at"] = now

        for m in data.get("models", []):
            if str(m.get("model_id")) == str(model_id):
                m["stage"] = stage
                m.setdefault("history", []).append({"event": "promote", "stage": stage, "actor": actor, "at": now})
                m["updated_at"] = now
                self._save(data)
                return {"ok": True, "model_id": model_id, "stage": stage}
        return {"ok": False, "error": "model_not_found"}

    def rollback_to(self, model_id: str, actor: str) -> Dict[str, Any]:
        data = self._load()
        now = datetime.now(timezone.utc).isoformat()
        target = None
        for m in data.get("models", []):
            if str(m.get("model_id")) == str(model_id):
                target = m
                break
        if target is None:
            return {"ok": False, "error": "model_not_found"}

        for m in data.get("models", []):
            if m.get("stage") == "production":
                m["stage"] = "staging"
                m["updated_at"] = now

        target["stage"] = "production"
        target.setdefault("history", []).append({"event": "rollback_promote", "actor": actor, "at": now})
        target["updated_at"] = now
        self._save(data)
        return {"ok": True, "model_id": model_id, "stage": "production"}
