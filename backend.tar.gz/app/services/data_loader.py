from __future__ import annotations

from io import BytesIO
from pathlib import Path
import tempfile

import pandas as pd


SUPPORTED_STRUCTURED = {".csv", ".tsv", ".txt", ".json", ".xls", ".xlsx", ".sas7bdat", ".sav", ".rdata"}


def load_dataframe_from_upload(filename: str, payload: bytes) -> pd.DataFrame:
    suffix = Path(filename).suffix.lower()
    buf = BytesIO(payload)

    if suffix == ".csv":
        return pd.read_csv(buf)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(buf, sep="\t")
    if suffix == ".json":
        return pd.read_json(buf)
    if suffix in {".xls", ".xlsx"}:
        return pd.read_excel(buf)
    if suffix == ".sas7bdat":
        try:
            import pyreadstat
            with tempfile.NamedTemporaryFile(suffix=".sas7bdat", delete=True) as tmp:
                tmp.write(payload)
                tmp.flush()
                df, _ = pyreadstat.read_sas7bdat(tmp.name)
            return df
        except Exception as exc:
            raise ValueError(f"Failed reading .sas7bdat. Install pyreadstat. Error: {exc}") from exc
    if suffix == ".sav":
        try:
            import pyreadstat
            with tempfile.NamedTemporaryFile(suffix=".sav", delete=True) as tmp:
                tmp.write(payload)
                tmp.flush()
                df, _ = pyreadstat.read_sav(tmp.name)
            return df
        except Exception as exc:
            raise ValueError(f"Failed reading .sav. Install pyreadstat. Error: {exc}") from exc
    if suffix == ".rdata":
        try:
            import pyreadr
            with tempfile.NamedTemporaryFile(suffix=".rdata", delete=True) as tmp:
                tmp.write(payload)
                tmp.flush()
                result = pyreadr.read_r(tmp.name)
            if not result:
                raise ValueError("No objects in RData file")
            first_key = next(iter(result.keys()))
            return result[first_key]
        except Exception as exc:
            raise ValueError(f"Failed reading .rdata. Install pyreadr. Error: {exc}") from exc

    raise ValueError(f"Unsupported file type: {suffix}. Supported: {sorted(SUPPORTED_STRUCTURED)}")
