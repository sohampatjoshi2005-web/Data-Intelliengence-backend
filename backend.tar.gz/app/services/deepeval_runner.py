from __future__ import annotations

from typing import Any, Dict, List, Optional, Type
import json
import asyncio

import boto3
import re

try:
    from deepeval.metrics import AnswerRelevancyMetric, FaithfulnessMetric
    from deepeval.test_case import LLMTestCase
    import deepeval.metrics as deepeval_metrics
    try:
        from deepeval.models import OllamaModel
    except Exception:
        OllamaModel = None
    try:
        from deepeval.models.base_model import DeepEvalBaseLLM
    except Exception:
        DeepEvalBaseLLM = None
except Exception:
    AnswerRelevancyMetric = None
    FaithfulnessMetric = None
    LLMTestCase = None
    OllamaModel = None
    DeepEvalBaseLLM = None


DEFAULT_METRICS = ["faithfulness", "answer_relevancy"]


if DeepEvalBaseLLM is None:
    class DeepEvalBaseLLM:  # type: ignore[no-redef]
        def get_model_name(self) -> str:  # pragma: no cover
            return "custom"

        def generate(self, prompt: str) -> str:  # pragma: no cover
            raise NotImplementedError

        async def a_generate(self, prompt: str) -> str:  # pragma: no cover
            return await asyncio.to_thread(self.generate, prompt)


class BedrockClaudeModel(DeepEvalBaseLLM):  # type: ignore[misc]
    def __init__(self, model_id: str, region: str, max_tokens: int = 512, temperature: float = 0.2):
        self._model_id = model_id
        self._region = region
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._client = boto3.client("bedrock-runtime", region_name=region)

    def get_model_name(self) -> str:
        return f"bedrock:{self._model_id}"

    def generate(self, prompt: str) -> str:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
            "messages": [{"role": "user", "content": [{"type": "text", "text": prompt}]}],
        }
        resp = self._client.invoke_model(
            modelId=self._model_id,
            body=json.dumps(body).encode("utf-8"),
            contentType="application/json",
            accept="application/json",
        )
        raw = resp["body"].read().decode("utf-8")
        data = json.loads(raw)
        content = data.get("content", [])
        if content and isinstance(content, list):
            return content[0].get("text", "") or ""
        return ""

    async def a_generate(self, prompt: str) -> str:
        return await asyncio.to_thread(self.generate, prompt)


def _build_model(model_name: Optional[str]):
    if not model_name:
        return None
    try:
        if model_name.lower() == "bedrock":
            from app.core.config import settings

            if not settings.bedrock_model_id:
                return None
            return BedrockClaudeModel(
                model_id=settings.bedrock_model_id,
                region=settings.bedrock_region,
                max_tokens=settings.bedrock_max_tokens,
                temperature=settings.bedrock_temperature,
            )
        if OllamaModel is None:
            return None
        return OllamaModel(model=model_name)
    except TypeError:
        try:
            return OllamaModel(model_name=model_name)
        except Exception:
            return None
    except Exception:
        return None


def _camel_metric_name(metric_name: str) -> str:
    parts = re.split(r"[^a-zA-Z0-9]+", metric_name.strip())
    parts = [p for p in parts if p]
    if not parts:
        return ""
    return "".join(p[:1].upper() + p[1:] for p in parts) + "Metric"


def _resolve_metric_class(metric_name: str) -> Optional[Type]:
    raw = metric_name.strip()
    if not raw:
        return None
    # Allow direct class name (case-insensitive)
    if deepeval_metrics is not None:
        try:
            for attr in dir(deepeval_metrics):
                if attr.lower() == raw.lower():
                    return getattr(deepeval_metrics, attr)
        except Exception:
            pass

    name = raw.lower()
    if name == "faithfulness":
        return FaithfulnessMetric
    if name in {"answer_relevancy", "answerrelevancy", "answerrelevancymetric"}:
        return AnswerRelevancyMetric

    # Strip trailing "metric" if provided
    if name.endswith("metric"):
        name = name[: -len("metric")]

    class_name = _camel_metric_name(name)
    if not class_name:
        return None
    # Case-insensitive lookup for camel case
    if deepeval_metrics is not None:
        try:
            for attr in dir(deepeval_metrics):
                if attr.lower() == class_name.lower():
                    return getattr(deepeval_metrics, attr)
        except Exception:
            pass
    return None


def _instantiate_metric(metric_cls: Type, threshold: float, model: Optional[Any]) -> Any:
    # Try common constructor signatures in order.
    last_exc: Exception | None = None
    try:
        return metric_cls(threshold=threshold, model=model)
    except Exception as exc:
        last_exc = exc
    try:
        return metric_cls(model=model)
    except Exception as exc:
        last_exc = exc
    try:
        return metric_cls(threshold=threshold)
    except Exception as exc:
        last_exc = exc
    try:
        metric = metric_cls()
        if model is not None and hasattr(metric, "model"):
            try:
                setattr(metric, "model", model)
            except Exception:
                pass
        return metric
    except Exception as exc:
        last_exc = exc
        return last_exc


def _bedrock_judge(model: BedrockClaudeModel, metric: str, input_text: str, output: str, context: Optional[str]) -> Dict[str, Any]:
    prompt = (
        "You are a strict evaluator. Return ONLY valid JSON.\n"
        "Schema: {\"score\": <number between 0 and 1>, \"reason\": \"...\"}\n"
        f"Metric: {metric}\n"
        f"User question: {input_text}\n"
        f"Model answer: {output}\n"
        f"Context: {context or 'N/A'}\n"
        "Score guidance:\n"
        "- 1.0 = perfect\n"
        "- 0.5 = partially correct/relevant\n"
        "- 0.0 = incorrect/irrelevant\n"
    )
    raw = model.generate(prompt)
    try:
        data = json.loads(raw)
        score = float(data.get("score", 0.0))
        reason = str(data.get("reason", "")).strip()
        return {"score": max(0.0, min(1.0, score)), "reason": reason}
    except Exception:
        return {"score": 0.0, "reason": f"judge_parse_failed: {raw[:200]}"}


def run_deepeval(
    *,
    input_text: str,
    actual_output: str,
    context: Optional[str] = None,
    model_name: Optional[str] = None,
    metrics: Optional[List[str]] = None,
    threshold: float = 0.7,
) -> Dict[str, Any]:
    if AnswerRelevancyMetric is None or FaithfulnessMetric is None or LLMTestCase is None:
        return {"status": "skipped", "reason": "deepeval not installed", "metrics": []}

    if not actual_output.strip():
        return {"status": "skipped", "reason": "no output to evaluate", "metrics": []}

    model = _build_model(model_name)
    if model is None and (model_name or "").lower() == "bedrock":
        try:
            from app.core.config import settings

            if settings.bedrock_model_id:
                model = BedrockClaudeModel(
                    model_id=settings.bedrock_model_id,
                    region=settings.bedrock_region,
                    max_tokens=settings.bedrock_max_tokens,
                    temperature=settings.bedrock_temperature,
                )
        except Exception:
            model = None
    selected = metrics or DEFAULT_METRICS
    results: List[Dict[str, Any]] = []

    # Hard override: if Bedrock is requested, use Bedrock judge directly
    if (model_name or "").lower() == "bedrock":
        if model is None:
            try:
                from app.core.config import settings

                if settings.bedrock_model_id:
                    model = BedrockClaudeModel(
                        model_id=settings.bedrock_model_id,
                        region=settings.bedrock_region,
                        max_tokens=settings.bedrock_max_tokens,
                        temperature=settings.bedrock_temperature,
                    )
            except Exception:
                model = None
        if isinstance(model, BedrockClaudeModel):
            for metric_name in selected:
                raw_name = str(metric_name).strip() or "metric"
                judge = _bedrock_judge(model, raw_name, input_text, actual_output, context)
                results.append(
                    {
                        "metric": raw_name.lower(),
                        "status": "pass" if float(judge["score"]) >= threshold else "fail",
                        "score": float(judge["score"]),
                        "reason": judge["reason"],
                    }
                )
            return {"status": "ok", "model": model_name or "", "metrics": results}

    for metric_name in selected:
        raw_name = str(metric_name).strip()
        metric_name = raw_name.lower()
        try:
            metric_cls = _resolve_metric_class(raw_name)
            if metric_cls is None:
                # Fallback mappings for common metrics
                if "answerrelevancy" in metric_name and AnswerRelevancyMetric is not None:
                    metric_cls = AnswerRelevancyMetric
                elif "faithfulness" in metric_name and FaithfulnessMetric is not None:
                    metric_cls = FaithfulnessMetric
                else:
                    results.append(
                        {"metric": metric_name, "status": "skipped", "score": 0.0, "reason": "unsupported metric"}
                    )
                    continue

            metric = _instantiate_metric(metric_cls, threshold=threshold, model=model)
            if isinstance(metric, Exception):
                # If DeepEval tries to initialize OpenAI-backed metrics without a key,
                # fall back to a Bedrock judge when available.
                if "OpenAI API key" in str(metric):
                    if model is None and (model_name or "").lower() == "bedrock":
                        try:
                            from app.core.config import settings

                            if settings.bedrock_model_id:
                                model = BedrockClaudeModel(
                                    model_id=settings.bedrock_model_id,
                                    region=settings.bedrock_region,
                                    max_tokens=settings.bedrock_max_tokens,
                                    temperature=settings.bedrock_temperature,
                                )
                        except Exception:
                            model = None
                if "OpenAI API key" in str(metric) and isinstance(model, BedrockClaudeModel):
                    judge = _bedrock_judge(model, raw_name, input_text, actual_output, context)
                    results.append(
                        {
                            "metric": metric_name,
                            "status": "pass" if float(judge["score"]) >= threshold else "fail",
                            "score": float(judge["score"]),
                            "reason": judge["reason"],
                        }
                    )
                    continue
                results.append(
                    {"metric": metric_name, "status": "error", "score": 0.0, "reason": f"metric init failed: {metric}"}
                )
                continue

            test_case = LLMTestCase(
                input=input_text or "",
                actual_output=actual_output or "",
                retrieval_context=[context] if context else None,
            )
            metric.measure(test_case)
            results.append(
                {
                    "metric": metric_name,
                    "status": "pass" if float(metric.score) >= threshold else "fail",
                    "score": float(metric.score),
                    "reason": getattr(metric, "reason", ""),
                }
            )
        except Exception as exc:
            results.append(
                {"metric": metric_name, "status": "error", "score": 0.0, "reason": f"error: {exc}"}
            )

    return {
        "status": "ok",
        "model": model_name or "",
        "metrics": results,
    }
