from __future__ import annotations

import os
from typing import Any, Optional

try:
    from langfuse import Langfuse
except Exception:
    Langfuse = None


def get_langfuse_client() -> Optional[Any]:
    public_key = os.getenv("LANGFUSE_PUBLIC_KEY", "pk-lf-e2b26ddb-9d61-4482-a103-2c472f17b869")
    secret_key = os.getenv("LANGFUSE_SECRET_KEY", "sk-lf-c59a1e7d-cc91-4fd2-865b-56cdce332d2c")
    host = os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com")
    if not public_key or not secret_key or Langfuse is None:
        return None
    try:
        return Langfuse(public_key=public_key, secret_key=secret_key, host=host)
    except Exception:
        return None


def trace_generation(name: str, model: str, prompt: str, output: str) -> None:
    client = get_langfuse_client()
    if client is None:
        return
    try:
        client.generation(name=name, model=model, input=prompt, output=output)
    except Exception:
        pass
