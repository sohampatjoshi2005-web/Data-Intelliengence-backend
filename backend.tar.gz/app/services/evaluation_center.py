from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EvalTool:
    name: str
    purpose: str
    status: str


EVAL_TOOLS = [
    EvalTool("LLM Studio", "Fine-tuning and experiment comparison", "planned"),
    EvalTool("Langfuse", "Tracing and online monitoring", "optional"),
    EvalTool("Custom Evals", "Task-specific offline benchmarks", "ready"),
    EvalTool("Prompt Regression Tests", "Prevent behavior regressions", "ready"),
]


def list_eval_tools() -> list[dict]:
    return [t.__dict__ for t in EVAL_TOOLS]
