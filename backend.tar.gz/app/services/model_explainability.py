from __future__ import annotations

from typing import Any, Dict, List

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split

try:
    import shap
except Exception:
    shap = None


def _clean_shap_reason(exc: Exception) -> str:
    raw = str(exc or "").lower()
    if "nopython" in raw or "numba" in raw:
        return "SHAP is not compatible with this model/pipeline in the current environment (numba backend issue)."
    if "mask" in raw or "explainer" in raw:
        return "SHAP explainer could not be constructed for this estimator."
    return "SHAP is unavailable for this model in the current setup."


def _split(df: pd.DataFrame, target: str, problem: str):
    X = df.drop(columns=[target])
    y = df[target]
    stratify = None
    if problem == "classification" and y.nunique(dropna=False) > 1:
        vc = y.value_counts(dropna=False)
        if not vc.empty and int(vc.min()) >= 2:
            stratify = y
    return train_test_split(X, y, test_size=0.2, random_state=42, stratify=stratify)


def explain_model(df: pd.DataFrame, target: str, problem: str, model: Any, top_n: int = 15) -> Dict[str, Any]:
    X_train, X_test, y_train, y_test = _split(df, target, problem)
    est = clone(model)
    est.fit(X_train, y_train)

    score_metric = "f1_weighted" if problem == "classification" else "r2"
    scoring = "f1_weighted" if problem == "classification" else "r2"

    out: Dict[str, Any] = {
        "score_metric": score_metric,
        "permutation_importance": [],
        "shap": {"enabled": False, "reason": "shap unavailable" if shap is None else "not_computed"},
    }

    try:
        pi = permutation_importance(est, X_test, y_test, n_repeats=5, random_state=42, scoring=scoring)
        feats: List[Dict[str, Any]] = []
        for idx, col in enumerate(X_test.columns):
            feats.append(
                {
                    "feature": str(col),
                    "importance_mean": float(pi.importances_mean[idx]),
                    "importance_std": float(pi.importances_std[idx]),
                }
            )
        feats.sort(key=lambda x: x["importance_mean"], reverse=True)
        out["permutation_importance"] = feats[:top_n]
    except Exception as exc:
        out["permutation_importance_error"] = str(exc)

    if shap is not None:
        try:
            sample = X_test.head(min(100, len(X_test)))
            explainer = shap.Explainer(est.predict, sample)
            sv = explainer(sample)
            mean_abs = np.abs(sv.values).mean(axis=0)
            rows = []
            for i, col in enumerate(sample.columns):
                rows.append({"feature": str(col), "mean_abs_shap": float(mean_abs[i])})
            rows.sort(key=lambda x: x["mean_abs_shap"], reverse=True)
            out["shap"] = {
                "enabled": True,
                "global_mean_abs": rows[:top_n],
                "sample_size": int(len(sample)),
            }
        except Exception as exc:
            out["shap"] = {"enabled": False, "reason": _clean_shap_reason(exc)}

    return out
