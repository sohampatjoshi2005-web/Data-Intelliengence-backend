from __future__ import annotations

from dataclasses import dataclass
import json
import boto3

from app.core.config import settings
from app.services.observability import trace_generation


@dataclass(frozen=True)
class AnalyticsModelConfig:
    model_name: str = settings.bedrock_model_id
    query_understanding_temperature: float = 0.0
    query_understanding_max_tokens: int = 16
    code_generation_temperature: float = 0.1
    code_generation_max_tokens: int = 1024
    reasoning_temperature: float = 0.5
    reasoning_max_tokens: int = 512
    insights_temperature: float = 0.3
    insights_max_tokens: int = 512


def _get_bedrock_client():
    return boto3.client("bedrock-runtime", region_name=settings.bedrock_region)


def chat_complete(
    prompt: str,
    temperature: float,
    max_tokens: int,
    trace_name: str = "analytics_chat",
) -> str:
    cfg = AnalyticsModelConfig()
    if not cfg.model_name:
        raise RuntimeError("BEDROCK_MODEL_ID is not set for analytics.")

    client = _get_bedrock_client()
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": int(max_tokens),
        "temperature": float(temperature),
        "messages": [{"role": "user", "content": [{"type": "text", "text": prompt}]}],
    }
    resp = client.invoke_model(
        modelId=cfg.model_name,
        body=json.dumps(body).encode("utf-8"),
        contentType="application/json",
        accept="application/json",
    )
    raw = resp["body"].read().decode("utf-8")
    data = json.loads(raw)
    content = data.get("content", [])
    output = ""
    if content and isinstance(content, list):
        output = content[0].get("text", "") or ""
    trace_generation(trace_name, cfg.model_name, prompt, output)
    return output
