from __future__ import annotations

import base64
import io
import json
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from app.services.model_explainability import explain_model

try:
    import optuna
except Exception:
    optuna = None

try:
    from river import drift, stats, tree
except Exception:
    drift = None
    stats = None
    tree = None

try:
    from xgboost import XGBClassifier, XGBRegressor
except Exception:
    XGBClassifier = None
    XGBRegressor = None

try:
    from lightgbm import LGBMClassifier, LGBMRegressor
except Exception:
    LGBMClassifier = None
    LGBMRegressor = None

try:
    from catboost import CatBoostClassifier, CatBoostRegressor
except Exception:
    CatBoostClassifier = None
    CatBoostRegressor = None


_PREDICTORS: Dict[str, Dict[str, Any]] = {}
_STREAMS: Dict[str, "StreamingScientist"] = {}


def _normalize_model_name(name: str, task: str) -> str:
    n = str(name).lower()
    if "random" in n and "forest" in n:
        return "random_forest" if task == "classification" else "random_forest_regressor"
    if "logistic" in n:
        return "logistic_regression"
    if "linear" in n:
        return "linear_regression"
    if "xgb" in n or "xgboost" in n:
        return "xgboost" if task == "classification" else "xgboost_regressor"
    if "lightgbm" in n or "lgbm" in n:
        return "lightgbm" if task == "classification" else "lightgbm_regressor"
    if "catboost" in n:
        return "catboost" if task == "classification" else "catboost_regressor"
    return n.replace(" ", "_")


def _build_preprocessor(df: pd.DataFrame, target: str) -> Tuple[ColumnTransformer, list[str], list[str]]:
    X = df.drop(columns=[target])
    num_cols = [c for c in X.columns if pd.api.types.is_numeric_dtype(X[c])]
    cat_cols = [c for c in X.columns if c not in num_cols]
    pre = ColumnTransformer(
        [
            ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num_cols),
            ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")), ("oh", OneHotEncoder(handle_unknown="ignore"))]), cat_cols),
        ]
    )
    return pre, num_cols, cat_cols


def _get_estimator(model_key: str, task: str):
    if task == "classification":
        pool = {
            "logistic_regression": LogisticRegression(max_iter=500),
            "random_forest": RandomForestClassifier(n_estimators=200, random_state=42),
            "xgboost": XGBClassifier(eval_metric="mlogloss", random_state=42) if XGBClassifier else None,
            "lightgbm": LGBMClassifier(random_state=42) if LGBMClassifier else None,
            "catboost": CatBoostClassifier(verbose=0, random_state=42) if CatBoostClassifier else None,
        }
    else:
        pool = {
            "linear_regression": LinearRegression(),
            "random_forest_regressor": RandomForestRegressor(n_estimators=200, random_state=42),
            "xgboost_regressor": XGBRegressor(random_state=42) if XGBRegressor else None,
            "lightgbm_regressor": LGBMRegressor(random_state=42) if LGBMRegressor else None,
            "catboost_regressor": CatBoostRegressor(verbose=0, random_state=42) if CatBoostRegressor else None,
        }
    est = pool.get(model_key)
    if est is None:
        fallback = "random_forest" if task == "classification" else "random_forest_regressor"
        est = pool[fallback]
    return est


def run_optuna_tuning(df: pd.DataFrame, target: str, task: str, model_key: str, n_trials: int = 20) -> Dict[str, Any]:
    if optuna is None:
        raise RuntimeError("optuna is not installed in this backend environment.")

    pre, _, _ = _build_preprocessor(df, target)
    X = df.drop(columns=[target])
    y = df[target]
    scoring = "accuracy" if task == "classification" else "r2"
    base_est = _get_estimator(model_key, task)
    base_pipe = Pipeline([("pre", pre), ("model", base_est)])
    baseline = float(np.mean(cross_val_score(base_pipe, X, y, cv=3, scoring=scoring)))

    trial_scores: list[float] = []
    best_scores: list[float] = []

    def objective(trial):
        est = _get_estimator(model_key, task)
        params = {}
        if hasattr(est, "n_estimators"):
            params["n_estimators"] = trial.suggest_int("n_estimators", 50, 400)
        if hasattr(est, "max_depth"):
            params["max_depth"] = trial.suggest_int("max_depth", 2, 20)
        if hasattr(est, "min_samples_split"):
            params["min_samples_split"] = trial.suggest_int("min_samples_split", 2, 12)
        if hasattr(est, "learning_rate"):
            params["learning_rate"] = trial.suggest_float("learning_rate", 0.01, 0.3, log=True)
        if hasattr(est, "subsample"):
            params["subsample"] = trial.suggest_float("subsample", 0.5, 1.0)
        if params:
            est.set_params(**params)
        pipe = Pipeline([("pre", pre), ("model", est)])
        score = float(np.mean(cross_val_score(pipe, X, y, cv=3, scoring=scoring)))
        trial_scores.append(score)
        best_scores.append(max(best_scores[-1], score) if best_scores else score)
        return score

    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=n_trials)
    tuned_score = float(study.best_value)
    improvement = tuned_score - baseline
    return {
        "baseline_score": baseline,
        "tuned_score": tuned_score,
        "improvement_abs": improvement,
        "improvement_pct": (improvement / abs(baseline) * 100.0) if baseline != 0 else 0.0,
        "best_params": study.best_params,
        "trial_scores": trial_scores,
        "best_scores": best_scores,
    }


def train_predictor(df: pd.DataFrame, target: str, task: str, model_key: str) -> Dict[str, Any]:
    pre, _, _ = _build_preprocessor(df, target)
    est = _get_estimator(model_key, task)
    pipe = Pipeline([("pre", pre), ("model", est)])
    X = df.drop(columns=[target])
    y = df[target]
    pipe.fit(X, y)
    model_id = str(uuid.uuid4())
    _PREDICTORS[model_id] = {
        "pipeline": pipe,
        "task": task,
        "features": list(X.columns),
    }
    return {"model_id": model_id, "task": task, "feature_columns": list(X.columns)}


def predict_with_model(model_id: str, rows: List[Dict[str, Any]], return_proba: bool = True) -> Dict[str, Any]:
    model_info = _PREDICTORS.get(model_id)
    if not model_info:
        raise ValueError("model_id not found. Train a predictor first.")
    pipe = model_info["pipeline"]
    task = model_info["task"]
    df = pd.DataFrame(rows)
    preds = pipe.predict(df).tolist()
    out: Dict[str, Any] = {"predictions": preds}
    if return_proba and task == "classification":
        model_obj = pipe.named_steps.get("model")
        if hasattr(model_obj, "predict_proba"):
            out["probabilities"] = pipe.predict_proba(df).tolist()
    return out


def run_explainability(df: pd.DataFrame, target: str, task: str, model_key: str, top_n: int = 15) -> Dict[str, Any]:
    pre, _, _ = _build_preprocessor(df, target)
    est = _get_estimator(model_key, task)
    pipe = Pipeline([("pre", pre), ("model", est)])
    return explain_model(df=df, target=target, problem=task, model=pipe, top_n=top_n)


class StreamingScientist:
    def __init__(self, task: str):
        self.available = tree is not None and drift is not None and stats is not None
        if not self.available:
            return
        self.task = task
        self.model = tree.HoeffdingAdaptiveTreeClassifier(
            grace_period=50,
            drift_detector=drift.ADWIN(),
            seed=42,
        )
        self.drift_detector = drift.ADWIN()
        from collections import deque

        self.history = deque(maxlen=200)
        self.accuracy_history = deque(maxlen=200)
        self.var_history = deque(maxlen=200)
        self.running_var = stats.Var()
        self.drift_events = 0
        self.total_count = 0
        self.correct_count = 0
        self.label_map: Dict[Any, int] = {}

    def process_sample(self, x: Dict[str, Any], y: Any) -> bool:
        if not self.available:
            return False
        self.total_count += 1
        if self.task == "classification":
            if y not in self.label_map:
                self.label_map[y] = len(self.label_map)
            y_val = self.label_map[y]
        else:
            y_val = float(y)

        self.running_var.update(y_val)
        self.var_history.append(self.running_var.get())
        y_pred = self.model.predict_one(x)
        error = 1 if y_pred != y_val else 0
        if error == 0:
            self.correct_count += 1
        self.model.learn_one(x, y_val)
        self.history.append(error)
        self.accuracy_history.append(self.correct_count / self.total_count)
        self.drift_detector.update(error)
        if self.drift_detector.drift_detected:
            self.drift_events += 1
            return True
        return False

    def snapshot(self) -> Dict[str, Any]:
        return {
            "drift_events": self.drift_events,
            "accuracy": float(self.accuracy_history[-1]) if self.accuracy_history else 0.0,
            "history": list(self.history),
            "accuracy_history": list(self.accuracy_history),
            "variance_history": list(self.var_history),
            "running_variance": float(self.var_history[-1]) if self.var_history else 0.0,
        }


def start_stream(task: str) -> Dict[str, Any]:
    engine = StreamingScientist(task=task)
    if not engine.available:
        raise RuntimeError("river is not installed in this backend environment.")
    stream_id = str(uuid.uuid4())
    _STREAMS[stream_id] = engine
    return {"stream_id": stream_id, "task": task}


def process_stream_batch(stream_id: str, rows: List[Dict[str, Any]], target: str, max_rows: int | None = None) -> Dict[str, Any]:
    engine = _STREAMS.get(stream_id)
    if not engine:
        raise ValueError("stream_id not found. Start a new stream first.")
    df = pd.DataFrame(rows)
    if max_rows:
        df = df.head(int(max_rows))
    drift_hits = 0
    for _, row in df.iterrows():
        hit = engine.process_sample(row.drop(target).to_dict(), row[target])
        if hit:
            drift_hits += 1
    snap = engine.snapshot()
    return {
        "processed": int(len(df)),
        "drift_hits": drift_hits,
        **snap,
    }


def get_stream_status(stream_id: str) -> Dict[str, Any]:
    engine = _STREAMS.get(stream_id)
    if not engine:
        raise ValueError("stream_id not found.")
    return engine.snapshot()


def stop_stream(stream_id: str) -> Dict[str, Any]:
    if stream_id in _STREAMS:
        _STREAMS.pop(stream_id, None)
        return {"stream_id": stream_id, "ok": True}
    return {"stream_id": stream_id, "ok": False}
