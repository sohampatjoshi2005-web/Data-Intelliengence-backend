from __future__ import annotations

import json
import uuid
from dataclasses import asdict
from typing import Any, Dict, Iterable, List

from app.services.unstructured_processing import EnrichedChunk

from app.core.config import settings

try:
    import chromadb
    from chromadb.utils.embedding_functions import OllamaEmbeddingFunction
except Exception:
    chromadb = None
    OllamaEmbeddingFunction = None


class GeneralVectorStore:
    """General vector storage for unstructured datasets (dataset-level isolation)."""

    def __init__(self, path: str = "./unified_kb", collection_name: str = "dataset_intel_v2") -> None:
        self.collection = None
        if chromadb and OllamaEmbeddingFunction:
            ef = OllamaEmbeddingFunction(
                url=f"{settings.ollama_base_url}/api/embeddings",
                model_name=settings.ollama_embed_model,
            )
            client = chromadb.PersistentClient(path=path)
            self.collection = client.get_or_create_collection(
                name=collection_name,
                embedding_function=ef,
            )

    def available(self) -> bool:
        return self.collection is not None

    def add_chunks(
        self,
        dataset_id: str,
        chunks: Iterable[EnrichedChunk],
    ) -> int:
        if not self.collection:
            return 0

        count = 0
        for chunk in chunks:
            metadata: Dict[str, Any] = {
                "dataset_id": dataset_id,
                "chunk_id": chunk.chunk_id,
                "summary": chunk.summary,
                "questions": json.dumps(chunk.questions),
                "headings": json.dumps(chunk.headings[:20]),
                "entities": json.dumps(chunk.entities),
                "relationships": json.dumps(chunk.relationships),
                "sentiment": float(chunk.sentiment),
            }
            self.collection.add(
                documents=[chunk.text],
                metadatas=[metadata],
                ids=[f"{dataset_id}_{uuid.uuid4()}"],
            )
            count += 1
        return count

    def query(self, query_text: str, dataset_id: str, n_results: int = 5) -> Dict[str, Any]:
        if not self.collection:
            return {}
        return self.collection.query(
            query_texts=[query_text],
            n_results=n_results,
            where={"dataset_id": dataset_id},
        )
